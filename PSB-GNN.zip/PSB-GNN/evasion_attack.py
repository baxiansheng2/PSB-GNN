import os
from models import model_map, choice_map
from common.utils import *

import argparse
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu_id', type=int, default=0)
    parser.add_argument('--logger_level', type=int, default=0)
    parser.add_argument('--dataset', type=str, default='pubmed',
                        choices=['cora', 'citeseer', 'pubmed', 'cora_ml'])
    parser.add_argument('--attack', type=str, default=[
         #'random',
        # 'dice',
        # 'greedy',
        #'pgdattack-CW',
        #'prbcd',
        #'greedy-rbcd',
        'pga',
    ])
    parser.add_argument('--victim', type=str, default='robust')
    parser.add_argument('--ptb_rate', type=float, default=0.05)
    parser.add_argument('--save', type=bool, default=True)
    parser.add_argument('--cmp', type=bool, default=True)

    parser.add_argument('--bias', type=float, default=None)      # 新增
    parser.add_argument('--threshold', type=float, default=None) # 新增

    args = parser.parse_args()
    assert args.gpu_id in range(0, 4)
    assert args.logger_level in [0, 1, 2]

    rng = 1 if not args.cmp else len(args.attack)

    # === 修复：文件名加入攻击方法名称，防止覆盖 ===
    # 处理列表或字符串
    att_name = args.attack if isinstance(args.attack, str) else str(args.attack)
    # 移除可能导致文件名的非法字符
    att_name = att_name.replace("['", "").replace("']", "").replace("'", "")
    
    logger_filename = f'evasion_attack-{args.dataset}-{args.victim}-{att_name}.log'
    # =================================================
    logger_name = 'evaluate'
    logger = get_logger(logger_filename, level=args.logger_level, name=logger_name)
    logger.info(args)

    device = get_device(args.gpu_id)
    logger.info(f"Device: {device}")
    # 读取数据
    init_seed = 15
    freeze_seed(init_seed)
    pyg_data = load_data(name=args.dataset)

    n_perturbs = int(args.ptb_rate * (pyg_data.num_edges // 2))
    logger.info(f"Rate of perturbation: {args.ptb_rate}")
    logger.info(f"The number of perturbations: {n_perturbs}")

    for ix in range(rng):

        logger.info("\n\n")
        attacker_name = args.attack if isinstance(args.attack, str) else args.attack[ix]

        # 读取攻击后得到的adj
        try:
            # 1. 尝试直接加载
            target_path = f'./attack/perturbed_adjs/{attacker_name}-{args.dataset}-{args.ptb_rate}.pth'
            
            # 2. 针对 PGD 的特殊处理 (如果文件不存在，尝试加后缀)
            if not os.path.exists(target_path) and 'pgd' in attacker_name:
                # 常见的 PGD 变体后缀
                candidates = [
                    f'{attacker_name}-CE-{args.dataset}-{args.ptb_rate}.pth',
                    f'{attacker_name}-CW-{args.dataset}-{args.ptb_rate}.pth',
                    f'{attacker_name}-tanhMargin-{args.dataset}-{args.ptb_rate}.pth'
                ]
                for cand in candidates:
                    full_cand_path = f'./attack/perturbed_adjs/{cand}'
                    if os.path.exists(full_cand_path):
                        # 修正 attacker_name 以匹配文件名格式，防止 load_perturbed_adj 内部再次拼错
                        # 注意：这里我们手动加载，绕过 utils.load_perturbed_adj 的拼名逻辑
                        import torch
                        perturbed_adj = torch.load(full_cand_path)
                        logger.info(f"redirect load pgd file: {full_cand_path}")
                        break
                else:
                    # 如果循环完了还没 break，说明真没找到，抛错
                    raise FileNotFoundError(f"Cannot find PGD file for {attacker_name}")
            else:
                # 非 PGD 或文件存在，使用标准加载
                perturbed_adj = load_perturbed_adj(args.dataset, attacker_name, args.ptb_rate,
                                                path='./attack/perturbed_adjs/')
            
            modified_adj_list = perturbed_adj['modified_adj_list']

        except FileNotFoundError:
            logger.error(f"[Skip] Attack file not found for {attacker_name}. Check gen_attack settings.")
            continue
        # ================================================================


        # ==================== 修复区域开始 ====================
        victims = []
        # 优先检查是否为单独的 registered model (如 noisygnn)
        if args.victim in model_map:
            victims = [args.victim]
        # 其次检查是否为预定义的 victim group (如 robust, normal)
        elif args.victim in choice_map:
            victims = choice_map[args.victim]
        else:
            raise ValueError(f"Victim name '{args.victim}' not found in model_map or choice_map.")
        # ==================== 修复区域结束 ====================

        raw_total_mean = []
        total_mean = []
        total_std = []

        for name in victims:
            # 加载预训练模型
            # 这里的路径是相对于运行目录的
            pretrained_models = load_pretrained_model(args.dataset, name, path='./victims/models/')
            state_dicts = pretrained_models['state_dicts']
            config = pretrained_models['config']
            clean_performance = pretrained_models['performance']

            # 实例化模型
            victim = model_map[name](config=config, pyg_data=pyg_data, device=device, logger=logger)
            victim = victim.to(device)

            # === 新增：动态覆盖 Inference Trick 参数 ===
            if args.bias is not None and hasattr(victim, 'bias'):
                victim.bias = args.bias
                logger.info(f"[{name}] Overwriting bias to {args.bias}")
                
            if args.threshold is not None and hasattr(victim, 'threshold'):
                victim.threshold = args.threshold
                logger.info(f"[{name}] Overwriting threshold to {args.threshold}")

            n_running = len(state_dicts)

            attack_acc_list = []
            init_seed = config['seed']
            for i in range(n_running):
                freeze_seed(init_seed + i)
                # 加载权重 (使用 strict=False 以兼容不同的保存格式)
                missing, unexpected = victim.load_state_dict(state_dicts[i], strict=False)
                if len(unexpected) > 0:
                    logger.warning(f"[{name}] Unexpected keys ignored when loading state_dict: {unexpected}")
                if len(missing) > 0:
                    logger.warning(f"[{name}] Missing keys when loading state_dict: {missing}")

                  # 修改后：(增加长度判断)
                if len(modified_adj_list) == 1 and n_running > 1:
                    # 广播模式：所有模型共用同一个攻击样本
                    mod_adj = modified_adj_list[0]
                elif i < len(modified_adj_list):
                    # 正常模式：一一对应
                    mod_adj = modified_adj_list[i]
                else:
                    # 兜底：防止越界，复用最后一个
                    logger.warning(f"Warning: Missing perturbation for run {i}, reusing last one.")
                    mod_adj = modified_adj_list[-1]
                # 评估
                attack_acc = evaluate_attack_performance(victim, pyg_data.x, mod_adj,
                                                         pyg_data.y, pyg_data.test_mask)
                attack_acc_list.append(attack_acc)

            total_mean.append(float(f"{np.mean(attack_acc_list) * 100:.2f}"))
            total_std.append(float(f"{np.std(attack_acc_list) * 100:.2f}"))
            logger.info(f"Clean Acc= {clean_performance}, "
                        f"Attacked Acc= {np.mean(attack_acc_list) * 100:.2f}{chr(177)}{np.std(attack_acc_list) * 100:.2f} \tModel= {name}")
            
            # 处理 clean performance 字符串，提取数值
            try:
                raw_acc = float(clean_performance.split(f'{chr(177)}')[0])
            except:
                raw_acc = 0.0 # Fallback
            raw_total_mean.append(raw_acc)

            if args.save:
                save_result_to_json(
                    attack=attacker_name,
                    dataset=args.dataset,
                    victim=name,
                    ptb_rate=args.ptb_rate,
                    attacked_acc=f"{np.mean(attack_acc_list) * 100:.2f}{chr(177)}{np.std(attack_acc_list) * 100:.2f}",
                    attack_type='evasion',
                )

        print("\n\n")
        logger.info(f"Averaged Attack Performance= {np.mean(total_mean):.2f}{chr(177)}{np.mean(total_std):.2f}")
        logger.info(f"Averaged Benigh Performance= {np.mean(raw_total_mean):.2f}")

        if args.victim in ['robust', 'normal', 'total'] and args.save:
            save_result_to_json(
                attack=attacker_name,
                dataset=args.dataset,
                victim=args.victim,
                ptb_rate=args.ptb_rate,
                attacked_acc=f"{np.mean(total_mean):.2f}{chr(177)}{np.mean(total_std):.2f}",
                attack_type='evasion',
            )


if __name__ == '__main__':
    main()
# attackers/pga_wrapper.py
# Wrapper for PGA attacker that ensures device alignment and robust handling
# of different adjacency representations (torch_sparse.SparseTensor, scipy.sparse, numpy arrays).
# - Compatible with main PGA class named `PGA` in attackers/pga.py
# - Accepts adv_args as dict (configurable)
#
# Usage: PGAAttackerWrapper(model, device, logger, **adv_args)
#        then call wrapper.generate(model, x, edge_index) to produce perturbed adj

import logging
from copy import deepcopy
from types import SimpleNamespace
import traceback

import torch
import numpy as np

# We'll import PGA lazily inside class to allow clearer errors if module missing
try:
    from attackers.pga import PGA
except Exception:
    PGA = None  # we will raise more informative error when attempted to instantiate

# Try to import torch_sparse.SparseTensor if available
try:
    from torch_sparse import SparseTensor as TorchSparseTensor
except Exception:
    TorchSparseTensor = None

# Try to import scipy for fallback conversions
try:
    import scipy.sparse as sp_sparse
except Exception:
    sp_sparse = None


def _is_scipy_sparse(x):
    return sp_sparse is not None and isinstance(x, sp_sparse.spmatrix)


def _to_device_best_effort(tensor_or_obj, device):
    """
    Try to move tensor_or_obj to device. Works for torch tensors and torch_sparse SparseTensor.
    If fails, return original object.
    """
    try:
        if hasattr(tensor_or_obj, "to"):
            return tensor_or_obj.to(device)
    except Exception:
        pass
    return tensor_or_obj


class _PygDataWrapper:
    """
    A minimal container that mimics the parts of torch_geometric.data.Data we need and
    implements .to(device) so PGA (or other attackers) can call pyg_data.to(device).
    Fields accepted: num_nodes, x, y, edge_index, adj_t, train_mask, val_mask, test_mask, any _orig
    """

    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)

    def to(self, device):
        """
        Best-effort move of common attributes to device. Returns self.
        """
        device = torch.device(device) if isinstance(device, (str, int, torch.device)) else device
        try:
            if hasattr(self, "x") and self.x is not None:
                try:
                    self.x = self.x.to(device)
                except Exception:
                    # if x is numpy, convert
                    try:
                        self.x = torch.as_tensor(self.x, device=device)
                    except Exception:
                        pass

            if hasattr(self, "y") and self.y is not None:
                try:
                    self.y = self.y.to(device)
                except Exception:
                    try:
                        self.y = torch.as_tensor(self.y, device=device)
                    except Exception:
                        pass

            if hasattr(self, "edge_index") and self.edge_index is not None:
                try:
                    # if already a tensor
                    self.edge_index = self.edge_index.to(device)
                except Exception:
                    try:
                        self.edge_index = torch.as_tensor(self.edge_index, device=device)
                    except Exception:
                        pass

            if hasattr(self, "adj_t") and self.adj_t is not None:
                # if torch_sparse SparseTensor
                if TorchSparseTensor is not None and isinstance(self.adj_t, TorchSparseTensor):
                    try:
                        self.adj_t = self.adj_t.to(device)
                    except Exception:
                        try:
                            self.adj_t = self.adj_t.cpu().to(device)
                        except Exception:
                            pass
                else:
                    # leave other types as-is (scipy sparse handled in wrapper conversion)
                    pass

            for mask in ("train_mask", "val_mask", "test_mask"):
                if hasattr(self, mask) and getattr(self, mask) is not None:
                    try:
                        setattr(self, mask, getattr(self, mask).to(device))
                    except Exception:
                        try:
                            setattr(self, mask, torch.as_tensor(getattr(self, mask), device=device))
                        except Exception:
                            pass
        except Exception:
            # swallow to ensure to() is best-effort
            pass
        return self


class PGAAttackerWrapper:
    """
    Robust wrapper for PGA attacker.
    - Moves model and data to device (best-effort).
    - Converts adjacency representations (scipy <-> torch_sparse) when possible.
    - Accepts attacker configuration via adv_args (a dict). If adv_args contains
      'adv_attacker_args' (nested), it will be merged.
    """

    def __init__(self, model, device="cpu", logger=None, **adv_args):
        if logger is None:
            logger = logging.getLogger("PGAAttackerWrapper")
        self.logger = logger
        self.device = torch.device(device) if isinstance(device, (str, int)) else device

        # Ensure PGA class is importable
        if PGA is None:
            raise ImportError("Could not import attackers.pga.PGA. Make sure attackers/pga.py exists and defines class PGA.")

        # Ensure model on device (best-effort)
        try:
            model = model.to(self.device)
        except Exception:
            # Some model implementations may not support .to() -> ignore
            pass
        self.model = model

        # Extract pyg_data from model (various possible attribute names used in repos)
        pyg_data = None
        for attr in ("pyg_data", "data", "_pyg_data", "dataset", "graph"):
            if hasattr(model, attr):
                pyg_data = getattr(model, attr)
                if pyg_data is not None:
                    break

        # If not found, allow passing pyg_data through adv_args
        if pyg_data is None:
            if "pyg_data" in adv_args and adv_args["pyg_data"] is not None:
                pyg_data = adv_args.pop("pyg_data")
            else:
                # We do not immediately raise; allow PGA to possibly operate without pyg_data,
                # but log and raise to match original behavior later.
                self.logger.warning("[ATTACKER] Model does not expose pyg_data/data; wrapper will try to proceed if adv_args provides pyg_data.")

        # Normalize adv_args: flatten nested adv_attacker_args if present
        attack_config = {}
        if adv_args:
            attack_config.update(adv_args)
        if "adv_attacker_args" in attack_config and isinstance(attack_config["adv_attacker_args"], dict):
            nested = attack_config.pop("adv_attacker_args")
            attack_config.update(nested)

        # Prepare device-aligned copy of pyg_data
        self.logger.info(f"[ATTACKER] Preparing pyg_data on device {self.device} for PGA attacker...")
        pyg_copy = None
        try:
            pyg_copy = self._build_device_pyg_copy(pyg_data, device=self.device)
        except Exception as e:
            self.logger.warning(f"[ATTACKER] Exception while building pyg_copy: {e}\n{traceback.format_exc()}")

        # As a final safety: ensure pyg_copy has a .to method (PGA may call pyg_data.to(device))
        if pyg_copy is None:
            # attempt to pass original pyg_data if present
            if pyg_data is None:
                raise RuntimeError("[ATTACKER] No pyg_data available for PGA attacker (neither model exposes it nor adv_args provided it).")
            else:
                # Try to move original pyg_data to device if possible
                try:
                    if hasattr(pyg_data, "to"):
                        pyg_data = pyg_data.to(self.device)
                        pyg_copy = pyg_data
                    else:
                        # wrap original into wrapper that implements to()
                        pymap = {"_orig": pyg_data}
                        # attempt to shallowly attach common attributes if possible
                        for key in ("num_nodes", "x", "y", "edge_index", "adj_t", "train_mask", "val_mask", "test_mask"):
                            try:
                                if hasattr(pyg_data, key):
                                    pymap[key] = getattr(pyg_data, key)
                            except Exception:
                                pass
                        pyg_copy = _PygDataWrapper(**pymap)
                except Exception:
                    pyg_copy = _PygDataWrapper(_orig=pyg_data)

        # instantiate PGA with device-aware pyg_copy
        try:
            # Some PGAs expect pyg_data to be a Data-like object with .to(device) method.
            # Our _PygDataWrapper implements .to(device).
            self.attacker = PGA(attack_config, pyg_copy, self.model, self.device, self.logger)
            self.logger.info(f"[ATTACKER] PGAAttackerWrapper initialized with config keys: {list(attack_config.keys())}")
        except Exception as e:
            # Provide helpful debug info in the log
            self.logger.warning(f"[ATTACKER] Failed to instantiate PGA attacker inside wrapper: {e}\n{traceback.format_exc()}")
            # Re-raise so train.py can decide how to handle (previous train.py caught and logged)
            raise

    def _build_device_pyg_copy(self, pyg_data, device):
        """
        Build a device-aligned pyg_data wrapper. Returns an object that implements .to(device).
        Handles:
          - torch_geometric Data-like objects
          - torch_sparse.SparseTensor adj_t
          - scipy sparse fallback
        """
        if pyg_data is None:
            return None

        device = torch.device(device) if isinstance(device, (str, int)) else device

        # If pyg_data has .to, try to call it first (many Data objects support this)
        try:
            if hasattr(pyg_data, "to"):
                try:
                    moved = pyg_data.to(device)
                    # If this succeeded and returned a different object, return it
                    return moved
                except Exception:
                    # Not fatal; continue with best-effort copy
                    pass
        except Exception:
            pass

        # Gather fields in a dict
        fields = {}
        # num_nodes
        try:
            fields["num_nodes"] = int(getattr(pyg_data, "num_nodes", None)) if getattr(pyg_data, "num_nodes", None) is not None else getattr(pyg_data, "n", None)
        except Exception:
            fields["num_nodes"] = None

        # x, y
        for name in ("x", "y"):
            try:
                val = getattr(pyg_data, name, None)
                if val is None:
                    fields[name] = None
                else:
                    # try to move
                    try:
                        fields[name] = val.to(device)
                    except Exception:
                        try:
                            fields[name] = torch.as_tensor(val, device=device)
                        except Exception:
                            fields[name] = val
            except Exception:
                fields[name] = None

        # edge_index
        try:
            eidx = getattr(pyg_data, "edge_index", None)
            if eidx is None:
                fields["edge_index"] = None
            else:
                try:
                    fields["edge_index"] = eidx.to(device)
                except Exception:
                    try:
                        fields["edge_index"] = torch.as_tensor(eidx, device=device)
                    except Exception:
                        # fallback: keep original
                        fields["edge_index"] = eidx
        except Exception:
            fields["edge_index"] = None

        # adj_t - multiple possibilities: torch_sparse.SparseTensor, scipy.sparse, other
        try:
            adj_val = getattr(pyg_data, "adj_t", None)
            if adj_val is None:
                fields["adj_t"] = None
            else:
                # If it's already a torch_sparse.SparseTensor
                if TorchSparseTensor is not None and isinstance(adj_val, TorchSparseTensor):
                    try:
                        fields["adj_t"] = adj_val.to(device)
                    except Exception:
                        try:
                            fields["adj_t"] = adj_val.cpu().to(device)
                        except Exception:
                            fields["adj_t"] = adj_val
                    # also set edge_index for convenience
                    try:
                        row, col, val = adj_val.coo()
                        fields["edge_index"] = torch.stack([row.to(device), col.to(device)], dim=0)
                    except Exception:
                        pass
                # If it's a scipy sparse matrix
                elif _is_scipy_sparse(adj_val):
                    # convert to coo and build torch tensors on device
                    try:
                        coo = adj_val.tocoo()
                        row = torch.from_numpy(coo.row.astype("int64")).to(device)
                        col = torch.from_numpy(coo.col.astype("int64")).to(device)
                        data = torch.from_numpy(coo.data.astype("float32")).to(device)
                        # Try to build torch_sparse.SparseTensor if available
                        if TorchSparseTensor is not None:
                            try:
                                st = TorchSparseTensor(row=row, col=col, value=data, sparse_sizes=(fields.get("num_nodes") or 0, fields.get("num_nodes") or 0)).to(device)
                                fields["adj_t"] = st
                                fields["edge_index"] = torch.stack([row, col], dim=0)
                            except Exception:
                                fields["edge_index"] = torch.stack([row, col], dim=0)
                                fields["adj_t"] = None
                        else:
                            fields["edge_index"] = torch.stack([row, col], dim=0)
                            fields["adj_t"] = None
                    except Exception:
                        fields["adj_t"] = adj_val
                else:
                    # Unknown type: try best-effort to call .to(device)
                    try:
                        fields["adj_t"] = adj_val.to(device)
                    except Exception:
                        fields["adj_t"] = adj_val
        except Exception:
            fields["adj_t"] = None

        # masks
        for mask in ("train_mask", "val_mask", "test_mask"):
            try:
                m = getattr(pyg_data, mask, None)
                if m is None:
                    fields[mask] = None
                else:
                    try:
                        fields[mask] = m.to(device)
                    except Exception:
                        try:
                            fields[mask] = torch.as_tensor(m, device=device)
                        except Exception:
                            fields[mask] = m
            except Exception:
                fields[mask] = None

        # keep orig pointer
        fields["_orig"] = pyg_data

        # Eager best-effort move: ensure tensors are on correct device where possible
        for k in ("x", "y", "edge_index"):
            v = fields.get(k)
            if v is not None and hasattr(v, "to"):
                try:
                    fields[k] = v.to(device)
                except Exception:
                    pass

        return _PygDataWrapper(**fields)

    def generate(self, model, x=None, edge_index=None):
        """
        Generate adversarial adjacency (SparseTensor or similar) using internal attacker.
        This mirrors the expected interface for an attacker wrapper used during adversarial training.
        """
        if not hasattr(self, "attacker") or self.attacker is None:
            raise RuntimeError("[ATTACKER] Internal PGA attacker not instantiated.")

        # compute n_perturb from attack_config if possible, else use default inside attacker
        cfg = getattr(self.attacker, "attack_config", None) or {}
        ptb = float(cfg.get("ptb_rate", cfg.get("ptb", 0.05)))
        n_nodes = getattr(self.attacker, "n", None)
        if n_nodes is None:
            # try to find in pyg_data
            pyg = getattr(self.attacker, "pyg_data", None)
            n_nodes = getattr(pyg, "num_nodes", None) if pyg is not None else None
        if n_nodes is None and hasattr(self, "model"):
            n_nodes = getattr(self.model, "num_nodes", None)
        if n_nodes is None:
            raise RuntimeError("[ATTACKER] Cannot determine number of nodes for computing n_perturbations")

        n_perturb = int(n_nodes * ptb)
        if n_perturb <= 0:
            n_perturb = max(1, int(max(1, n_nodes * 0.01)))

        try:
            self.logger.info(f"[ATTACKER] Generating adversarial graph with n_perturb={n_perturb} (ptb_rate={ptb})")
            # Ensure attacked_model inside attacker is on device
            try:
                if hasattr(self.attacker, "attacked_model") and self.attacker.attacked_model is not None:
                    try:
                        self.attacker.attacked_model = self.attacker.attacked_model.to(self.device)
                    except Exception:
                        pass
            except Exception:
                pass

            # call underlying attack method; PGA implementation should accept the configured pyg_data
            self.attacker._attack(n_perturbations=n_perturb)
            perturbed_adj = None
            try:
                perturbed_adj = self.attacker.get_modified_adj()
            except Exception:
                # some attackers may return other names
                if hasattr(self.attacker, "adj_adversary"):
                    perturbed_adj = getattr(self.attacker, "adj_adversary")
            if perturbed_adj is not None:
                try:
                    perturbed_adj = perturbed_adj.to(self.device)
                except Exception:   
                    pass
            return perturbed_adj
        except Exception as e:
            self.logger.warning(f"[ATTACKER] Attack generation failed: {e}\n{traceback.format_exc()}")
            raise

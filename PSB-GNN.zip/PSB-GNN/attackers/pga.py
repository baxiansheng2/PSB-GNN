# attackers/pga.py
import numpy as np
import torch
import torch.nn.functional as F
from copy import deepcopy
from attackers.base import AttackABC
from tqdm import tqdm
from common.utils import *
from torch_geometric.utils import k_hop_subgraph, coalesce as pyg_coalesce
from torch_sparse import coalesce
from torch_sparse import SparseTensor as TorchSparseTensor  # sometimes used

# If your project uses SparseTensor from torch_sparse, import above.
# Ensure imports match your project conventions.


def select_attacking_targets(logits, labels, idx_attack, adj_t, policy, pre_ratio, select_ratio):

    correct_mask = logits.argmax(1).cpu() == labels.cpu()
    index_attack = torch.nonzero(correct_mask & idx_attack.cpu()).flatten().detach().cpu()

    margins = classification_margin(logits, labels)[index_attack]
    degrees = calculate_degree(adj_t)[index_attack]

    n_nodes = index_attack.size(0)

    sorted_margins, _ = margins.sort()
    margin_threshold = sorted_margins[int(pre_ratio * n_nodes)]
    pre_mask = torch.where(margins > margin_threshold, True, False)

    margins = margins[pre_mask]
    degrees = degrees[pre_mask]
    index_attack = index_attack[pre_mask]

    n_nodes = index_attack.size(0)
    selected_idx = torch.arange(0, n_nodes)
    n_selected = int(select_ratio * n_nodes)

    indicators = [
        degrees,
        margins,
    ]

    for item in indicators:
        _, sorted_index = item.sort()
        item_selected = sorted_index[:n_selected]
        selected_idx = torch.tensor(np.intersect1d(item_selected.cpu().numpy(), selected_idx.cpu().numpy()),
                                    dtype=torch.long)

    return index_attack[selected_idx]


class PGA(AttackABC):

    def __init__(self,
                 attack_config, pyg_data,
                 model, device, logger, **kwargs):
        super(PGA, self).__init__(attack_config, pyg_data, model, device, logger)

        # attack config
        self.greedy_steps = self.attack_config.get('greedy_steps', 20)
        self.pre_ratio = self.attack_config.get('pre_ratio', 0.2)
        self.select_ratio = self.attack_config.get('select_ratio', 0.2)
        self.influ_ratio = self.attack_config.get('influ_ratio', 0.2)
        self.select_policy = self.attack_config.get('select_policy', 'degree')
        self.loss_type = self.attack_config.get('loss_type', 'CE')

        # ensure attacked model exists
        self.attacked_model.with_relu = False

        # dataset related
        self.x = self.pyg_data.x.to(self.device)
        # adj as SparseTensor on device
        try:
            self.adj = self.pyg_data.adj_t.to(self.device)
        except Exception:
            # fallback: keep original
            self.adj = self.pyg_data.adj_t

        self.labels = self.pyg_data.y.to(self.device)
        self.n = int(self.pyg_data.num_nodes)

        # edge_index copy -> ensure it's on desired device (PyG edge_index)
        self.edge_index = deepcopy(self.pyg_data.edge_index)
        if torch.is_tensor(self.edge_index):
            try:
                self.edge_index = self.edge_index.to(self.device)
            except Exception:
                # keep as-is; conversion later where needed
                pass

        self.attacking_targets = None
        self.anchor_labels = None

        self.idx_attack = self.pyg_data.test_mask

    def _attack(self, n_perturbations, **kwargs):

        logits = self.attacked_model.predict().cpu()

        # Select targets (returns CPU tensors)
        self.attacking_targets = select_attacking_targets(
            logits, self.labels.cpu(), self.idx_attack, self.adj,
            self.select_policy, self.pre_ratio, self.select_ratio)

        # anchor labels -> move to device
        self.anchor_labels = kth_best_wrong_label(
            logits[self.attacking_targets],
            self.labels[self.attacking_targets].cpu()
        ).to(self.device)

        (
            edge_index, non_edge_index, self_loop, edges_all,
            edge_weight, non_edge_weight, self_loop_weight
        ) = self._construct_modified_edges()

        # split steps to greedy chunks
        steps = [self.greedy_steps] * (n_perturbations // self.greedy_steps)
        for i in range(n_perturbations % self.greedy_steps):
            steps[i] += 1

        added_set = set()
        removed_set = set()

        for step_size in tqdm(steps, desc='Attacking...'):
            weights = torch.cat([edge_weight, edge_weight,
                                 non_edge_weight, non_edge_weight,
                                 self_loop_weight], dim=-1)
            edge_grad, non_edge_grad = self._compute_gradient(edges_all, weights, (edge_weight, non_edge_weight))
            i = 0
            while i < step_size:
                max_edge_grad, max_edge_idx = torch.max(edge_grad, dim=0)
                max_non_edge_grad, max_non_edge_idx = torch.max(non_edge_grad, dim=0)
                if max_edge_grad.max().item() == 0.0 and max_non_edge_grad.max().item() == 0:
                    break

                if max_edge_grad > max_non_edge_grad:  # 删除边
                    edge_grad.data[max_edge_idx] = 0.0
                    best_edge = edge_index[:, max_edge_idx]
                    best_edge_reverse = best_edge[[1, 0]]
                    edge_weight.data[max_edge_idx] = 0.0

                    mask = ~((self.edge_index == best_edge.reshape(-1, 1)).all(0) |
                             (self.edge_index == best_edge_reverse.reshape(-1, 1)).all(0))
                    # keep device of edge_index
                    self.edge_index = self.edge_index[:, mask]

                    u, v = best_edge.tolist()
                    if (u, v) in removed_set or (v, u) in removed_set:
                        continue
                    removed_set.add((u, v))

                else:  # 加边
                    non_edge_grad.data[max_non_edge_idx] = 0.0
                    best_edge = non_edge_index[:, max_non_edge_idx]
                    best_edge_reverse = best_edge[[1, 0]]
                    non_edge_weight.data[max_non_edge_idx] = 1.0
                    self.edge_index = pyg_coalesce(
                        torch.cat([
                            self.edge_index, best_edge.reshape(-1, 1), best_edge_reverse.reshape(-1, 1),
                        ], dim=1)
                    )
                    u, v = best_edge.tolist()
                    if (u, v) in added_set or (v, u) in added_set:
                        continue
                    added_set.add((u, v))

                i += 1

        # final adversarial adj (SparseTensor)
        self.adj_adversary = SparseTensor.from_edge_index(edge_index=self.edge_index,
                                                          sparse_sizes=(self.n, self.n)).coalesce().detach()

    def _construct_modified_edges(self):
        # get k-hop subgraph around targets (edge_index must be available)
        sub_nodes, sub_edges, *_ = k_hop_subgraph(self.attacking_targets.to(self.device), 2, self.edge_index)
        sub_edges = sub_edges[:, sub_edges[0] < sub_edges[1]]

        # neighbors from original adjacency -> return CPU numpy indices safely
        neighbors_np = self._targets_neighbors().cpu().numpy()

        # anchors: all nodes of types in anchor_labels, excluding neighbors
        anchors_list = []
        type_set = set(self.anchor_labels.cpu().tolist())
        for node_type in type_set:
            anchors_list.extend(torch.where(self.labels.cpu() == node_type)[0].tolist())

        # anchors as numpy on CPU; perform setdiff using numpy then back to device
        anchors_np = np.array(anchors_list, dtype=np.int64)
        anchors_np = np.setdiff1d(anchors_np, neighbors_np, assume_unique=False)

        # generate edges using CPU numpy anchors but return torch tensors on device
        anchors_tensor = torch.as_tensor(anchors_np, dtype=torch.long, device=self.device)

        (
            edge_index, non_edge_index, self_loop, edges_all,
            edge_weight, non_edge_weight, self_loop_weight
        ) = self._gen_edges(anchors_tensor, sub_nodes, sub_edges)

        weights = torch.cat([edge_weight, edge_weight,
                             non_edge_weight, non_edge_weight,
                             self_loop_weight], dim=-1)

        k = max(1, int(self.influ_ratio * len(anchors_np)))  # at least 1

        add_gradient = self._compute_gradient(edges_all, weights, (non_edge_weight, ))[0]
        _, topk_nodes = torch.topk(add_gradient, k=k, sorted=False)

        # non_edge_index[1] may be on device; move to CPU for numpy ops
        topk_cpu = topk_nodes.cpu()
        non_edge_idx_col = non_edge_index[1].cpu().numpy()
        selected_cols = non_edge_idx_col[topk_cpu.numpy()]
        anchors_np_2 = np.unique(selected_cols)

        # regenerate final edges with anchors found
        anchors_tensor = torch.as_tensor(anchors_np_2, dtype=torch.long, device=self.device)

        # free and regenerate
        del edge_index, non_edge_index, self_loop, edges_all
        del edge_weight, non_edge_weight, self_loop_weight
        torch.cuda.empty_cache()

        (
            edge_index, non_edge_index, self_loop, edges_all,
            edge_weight, non_edge_weight, self_loop_weight
        ) = self._gen_edges(anchors_tensor, sub_nodes, sub_edges)

        return (
            edge_index, non_edge_index, self_loop, edges_all,
            edge_weight, non_edge_weight, self_loop_weight
        )

    def get_modified_adj(self):
        return SparseTensor.from_edge_index(edge_index=self.edge_index, sparse_sizes=(self.n, self.n)).coalesce().detach()

    def _targets_subgraph(self):
        sub_nodes, sub_edges, *_ = k_hop_subgraph(self.attacking_targets.to(self.device), 2, self.edge_index)
        sub_edges = sub_edges[:, sub_edges[0] < sub_edges[1]]
        return sub_nodes.cpu(), sub_edges.cpu()

    def _targets_neighbors(self):
        # returns CPU tensor of neighbor indices (for consistent numpy ops)
        try:
            # try using adjacency's SciPy view safely on CPU
            sp = self.adj[self.attacking_targets.to(self.device)].to_scipy(layout='csr')
            neigh = sp.nonzero()[1]
            return torch.as_tensor(neigh, dtype=torch.long)
        except Exception:
            # fallback: fetch via torch operations and ensure CPU
            # self.adj may be SparseTensor; try to convert to coo and extract
            try:
                t = self.adj[self.attacking_targets.to(self.device)].to_scipy(layout='csr').nonzero()[1]
                return torch.as_tensor(t, dtype=torch.long)
            except Exception:
                # safe fallback: use adjacency edge_index to gather neighbors
                # edge_index likely on device; move to CPU for numpy
                ei = self.pyg_data.edge_index.cpu().numpy()
                targets_np = self.attacking_targets.cpu().numpy()
                # collect neighbors
                neighs = np.unique(ei[1][np.isin(ei[0], targets_np)])
                return torch.as_tensor(neighs, dtype=torch.long)

    def _select_anchors(self, neighbors):
        anchors_list = []
        type_set = set(self.anchor_labels.cpu().tolist())
        for node_type in type_set:
            anchors_list.extend(torch.where(self.labels.cpu() == node_type)[0].tolist())
        anchors_np = np.setdiff1d(np.array(anchors_list, dtype=np.int64), neighbors.cpu().numpy(), assume_unique=False)
        return torch.as_tensor(anchors_np, dtype=torch.long, device=self.device)

    def _gen_edges(self, anchors, sub_nodes, sub_edges):
        # anchors is torch tensor on device; move to CPU numpy for building non-edges reliably
        anchors_cpu = anchors.cpu().numpy()
        targets_cpu = self.attacking_targets.cpu().numpy()

        # row / col in numpy then to torch on device
        row = np.repeat(targets_cpu, len(anchors_cpu))
        col = np.tile(anchors_cpu, targets_cpu.shape[0])

        non_edges = np.row_stack([row, col]).astype(np.int64)

        # unique nodes = union of sub_nodes and anchors (sub_nodes may be tensor on device)
        try:
            sub_nodes_cpu = sub_nodes.cpu().numpy()
        except Exception:
            sub_nodes_cpu = np.array(sub_nodes, dtype=np.int64)

        unique_nodes = np.union1d(sub_nodes_cpu, anchors_cpu)

        # convert to torch on device
        non_edges_t = torch.as_tensor(non_edges, device=self.device, dtype=torch.long)
        unique_nodes_t = torch.as_tensor(unique_nodes, dtype=torch.long, device=self.device)

        # self_loop: pair each unique node with itself
        self_loop = unique_nodes_t.repeat((2, 1))

        # edges_all: concat sub_edges (may be on device) and non_edges and loops
        # ensure sp_edges on same device
        if not torch.is_tensor(sub_edges):
            sub_edges = torch.as_tensor(sub_edges, dtype=torch.long, device=self.device)
        else:
            try:
                sub_edges = sub_edges.to(self.device)
            except Exception:
                pass

        edges_all = torch.cat([
            sub_edges, sub_edges[[1, 0]],
            non_edges_t, non_edges_t[[1, 0]],
            self_loop.to(self.device),
        ], dim=1)

        edge_weight = torch.ones(sub_edges.size(1), device=self.device).requires_grad_(True)
        non_edge_weight = torch.zeros(non_edges_t.size(1), device=self.device).requires_grad_(True)
        self_loop_weight = torch.ones(self_loop.size(1), device=self.device)

        return (
            sub_edges, non_edges_t, self_loop, edges_all,
            edge_weight, non_edge_weight, self_loop_weight
        )

    def _compute_gradient(self, edges_all, weights, inputs, target_weight=None):
        inputs = (inputs,) if isinstance(inputs, torch.Tensor) else tuple(inputs)
        if target_weight is not None:
            inputs = inputs + (target_weight, )
        logit = self._calc_logit(edges_all, weights)
        loss = self._calc_loss(logit, target_weight=target_weight)
        gradients = torch.autograd.grad(loss, inputs, create_graph=False)
        return gradients

    def _calc_logit(self, edges_all, weights_all):
        # Assemble full edge_index and edge_weight (ensure device consistency)
        edge_index = torch.cat([self.edge_index, edges_all], dim=-1)

        edge_weight = torch.cat([
            torch.ones(self.edge_index.size(1), dtype=torch.float32, device=self.device),
            weights_all.to(self.device)
        ], dim=-1)

        edge_index, edge_weight = coalesce(edge_index, edge_weight, m=self.n, n=self.n, op='sum')
        mod_adj_t = SparseTensor.from_edge_index(edge_index, edge_weight, (self.n, self.n))
        logit = self.attacked_model.forward(self.x, mod_adj_t, edge_weight)
        return logit

    def _calc_loss(self, logit, eps=5.0, target_weight=None):

        loss = None
        targets = self.attacking_targets.to(self.device)
        labels = self.labels[targets]
        if self.loss_type == 'CW':
            logit_s = F.log_softmax(logit / eps, dim=1)
            loss = F.nll_loss(logit_s[targets], labels) - \
                   F.nll_loss(logit_s[targets], self.anchor_labels)
        elif self.loss_type == 'CE':
            loss = F.cross_entropy(logit[targets], labels)
        elif self.loss_type == 'MCE':
            target_preds = logit[targets].argmax(1)
            not_flipped = target_preds == labels
            loss = F.cross_entropy(logit[targets][not_flipped], labels[not_flipped])
        elif self.loss_type == 'MCW':
            target_preds = logit[targets].argmax(1)
            logit_l = F.log_softmax(logit, dim=1)
            not_flipped = target_preds == labels
            loss = F.nll_loss(logit_l[targets][not_flipped], labels[not_flipped]) - \
                   F.nll_loss(logit_l[targets][not_flipped], self.anchor_labels[not_flipped])
        elif self.loss_type == 'tanhMargin':
            target_preds = logit[targets].argmax(1)
            not_flipped = target_preds == labels
            logit_safe = logit[targets][not_flipped]
            margin_safe = (
                logit_safe[np.arange(logit_safe.size(0)), labels[not_flipped]]
                - logit_safe[np.arange(logit_safe.size(0)), self.anchor_labels[not_flipped]]
            )
            loss = torch.tanh(-margin_safe).mean()
        elif self.loss_type.startswith('tanhMarginMCE-'):
            alpha = float(self.loss_type.split('-')[-1])
            target_preds = logit[targets].argmax(1)
            not_flipped = target_preds == labels
            logit_safe = logit[targets][not_flipped]
            margin_safe = (
                logit_safe[np.arange(logit_safe.size(0)), labels[not_flipped]]
                - logit_safe[np.arange(logit_safe.size(0)), self.anchor_labels[not_flipped]]
            )
            loss = alpha * torch.tanh(-margin_safe) + (1 - alpha) * F.cross_entropy(
                logit[targets][not_flipped], labels[not_flipped], reduction='none')
            if target_weight is not None:
                loss = target_weight[not_flipped] * loss
            loss = loss.mean()

        assert loss is not None, f"Not support loss type: {self.loss_type}"

        return loss


class PoisonPGA(PGA):

    def __init__(self,
                 attack_config, pyg_data,
                 model, device, logger, **kwargs):
        super(PoisonPGA, self).__init__(attack_config, pyg_data, model, device, logger, **kwargs)

        # surrogate model constructed in same style as attacked_model
        self.surrogate = type(self.attacked_model)(
            self.attacked_model.config, pyg_data, device, logger,
            with_relu=False)
        # move surrogate to device (its .to should be implemented in your model classes)
        try:
            self.surrogate = self.surrogate.to(self.device)
        except Exception:
            pass

    def inner_train(self, adj_t):
        # fit surrogate on modified adjacency; adj_t should be a SparseTensor on device
        self.surrogate.fit(self.pyg_data, adj_t=adj_t, train_iters=100, verbose=False)

    def _calc_logit(self, edges_all, weights_all):
        # same as PGA but using surrogate forward
        edge_index = torch.cat([self.edge_index, edges_all], dim=-1)

        edge_weight = torch.cat([
            torch.ones(self.edge_index.size(1), dtype=torch.float32, device=self.device),
            weights_all.to(self.device)
        ], dim=-1)

        edge_index, edge_weight = coalesce(edge_index, edge_weight, m=self.n, n=self.n, op='sum')
        mod_adj_t = SparseTensor.from_edge_index(edge_index, edge_weight, (self.n, self.n))
        logit = self.surrogate.forward(self.x, mod_adj_t, edge_weight)
        return logit

﻿# attackers/pga.py
import numpy as np
import torch
import torch.nn.functional as F
from copy import deepcopy
from attackers.base import AttackABC
from tqdm import tqdm
from common.utils import *
from torch_geometric.utils import k_hop_subgraph, coalesce as pyg_coalesce
from torch_sparse import coalesce
from torch_sparse import SparseTensor as TorchSparseTensor
from torch_sparse import SparseTensor

def select_attacking_targets(logits, labels, idx_attack, adj_t, policy, pre_ratio, select_ratio):
    correct_mask = logits.argmax(1).cpu() == labels.cpu()
    index_attack = torch.nonzero(correct_mask & idx_attack.cpu()).flatten().detach().cpu()

    margins = classification_margin(logits, labels)[index_attack]
    degrees = calculate_degree(adj_t)[index_attack]

    n_nodes = index_attack.size(0)
    if n_nodes == 0:
        return index_attack  # empty

    sorted_margins, _ = margins.sort()
    margin_threshold = sorted_margins[int(pre_ratio * n_nodes)]
    pre_mask = torch.where(margins > margin_threshold, True, False)

    margins = margins[pre_mask]
    degrees = degrees[pre_mask]
    index_attack = index_attack[pre_mask]

    n_nodes = index_attack.size(0)
    if n_nodes == 0:
        return index_attack

    selected_idx = torch.arange(0, n_nodes)
    n_selected = max(1, int(select_ratio * n_nodes))

    indicators = [degrees, margins]

    for item in indicators:
        _, sorted_index = item.sort()
        item_selected = sorted_index[:n_selected]
        selected_idx = torch.tensor(np.intersect1d(item_selected.cpu().numpy(), selected_idx.cpu().numpy()),
                                    dtype=torch.long)

    return index_attack[selected_idx]


class PGA(AttackABC):

    def __init__(self,
                 attack_config, pyg_data,
                 model, device, logger, **kwargs):
        super(PGA, self).__init__(attack_config, pyg_data, model, device, logger)

        self.greedy_steps = int(self.attack_config.get('greedy_steps', 20))
        self.pre_ratio = float(self.attack_config.get('pre_ratio', 0.2))
        self.select_ratio = float(self.attack_config.get('select_ratio', 0.2))
        self.influ_ratio = float(self.attack_config.get('influ_ratio', 0.2))
        self.select_policy = self.attack_config.get('select_policy', 'degree')
        self.loss_type = self.attack_config.get('loss_type', 'CE')

        self.attacked_model.with_relu = False

        self.x = self.pyg_data.x.to(self.device)
        try:
            self.adj = self.pyg_data.adj_t.to(self.device)
        except Exception:
            self.adj = self.pyg_data.adj_t

        self.labels = self.pyg_data.y.to(self.device)
        self.n = int(self.pyg_data.num_nodes)

        self.edge_index = deepcopy(self.pyg_data.edge_index)
        if torch.is_tensor(self.edge_index):
            try:
                self.edge_index = self.edge_index.to(self.device)
            except Exception:
                pass

        self.attacking_targets = None
        self.anchor_labels = None
        self.idx_attack = self.pyg_data.test_mask

    def _attack(self, n_perturbations, **kwargs):
        # predict on current model (cpu) to select targets
        logits = self.attacked_model.predict().cpu()

        self.attacking_targets = select_attacking_targets(
            logits, self.labels.cpu(), self.idx_attack, self.adj,
            self.select_policy, self.pre_ratio, self.select_ratio)

        if self.attacking_targets.numel() == 0:
            # nothing to attack
            self.adj_adversary = self.adj
            return

        self.anchor_labels = kth_best_wrong_label(
            logits[self.attacking_targets],
            self.labels[self.attacking_targets].cpu()
        ).to(self.device)

        (
            edge_index, non_edge_index, self_loop, edges_all,
            edge_weight, non_edge_weight, self_loop_weight
        ) = self._construct_modified_edges()

        # ---------------------------
        # 淇敼鐐癸紙淇瓒婄晫锛夛細鏋勯€?steps 鐨勫仴澹柟娉?        # 淇敼鍓?--> steps = [self.greedy_steps] * (n_perturbations // self.greedy_steps)
        #              for i in range(n_perturbations % self.greedy_steps): steps[i] += 1
        # 闂锛氬綋 n_perturbations < self.greedy_steps 鏃讹紝steps 涓虹┖锛?indexing 瓒婄晫銆?        # 淇敼鍚?--> 浣跨敤 divmod 鏉ュ畨鍏ㄥ垎閰嶅苟鍦?q==0 鏃舵纭鐞嗕綑鏁?r銆?        # ---------------------------
        q, r = divmod(int(n_perturbations), self.greedy_steps)
        if q == 0:
            # fewer perturbations than greedy_steps -> make r chunks of size 1
            steps = [1] * r
        else:
            # distribute r extra +1 among first r chunks
            steps = [self.greedy_steps + (1 if i < r else 0) for i in range(q)]

        # ---------------------------

        added_set = set()
        removed_set = set()

        for step_size in tqdm(steps, desc='Attacking...'):
            if step_size <= 0:
                continue

            weights = torch.cat([edge_weight, edge_weight,
                                 non_edge_weight, non_edge_weight,
                                 self_loop_weight], dim=-1)

            # compute gradients wrt edge/non-edge weights
            edge_grad, non_edge_grad = self._compute_gradient(edges_all, weights, (edge_weight, non_edge_weight))
            i = 0
            while i < step_size:
                # pick best gradient indices
                max_edge_grad, max_edge_idx = torch.max(edge_grad, dim=0)
                max_non_edge_grad, max_non_edge_idx = torch.max(non_edge_grad, dim=0)

                # if all grads zero => nothing to do
                if max_edge_grad.max().item() == 0.0 and max_non_edge_grad.max().item() == 0.0:
                    break

                if max_edge_grad > max_non_edge_grad:
                    # remove edge
                    edge_grad.data[max_edge_idx] = 0.0
                    best_edge = edge_index[:, max_edge_idx]
                    best_edge_reverse = best_edge[[1, 0]]
                    edge_weight.data[max_edge_idx] = 0.0

                    mask = ~((self.edge_index == best_edge.reshape(-1, 1)).all(0) |
                             (self.edge_index == best_edge_reverse.reshape(-1, 1)).all(0))
                    self.edge_index = self.edge_index[:, mask]

                    u, v = best_edge.tolist()
                    if (u, v) in removed_set or (v, u) in removed_set:
                        # skip duplicates
                        continue
                    removed_set.add((u, v))

                else:
                    # add edge
                    non_edge_grad.data[max_non_edge_idx] = 0.0
                    best_edge = non_edge_index[:, max_non_edge_idx]
                    best_edge_reverse = best_edge[[1, 0]]
                    non_edge_weight.data[max_non_edge_idx] = 1.0
                    self.edge_index = pyg_coalesce(
                        torch.cat([
                            self.edge_index, best_edge.reshape(-1, 1), best_edge_reverse.reshape(-1, 1),
                        ], dim=1)
                    )
                    u, v = best_edge.tolist()
                    if (u, v) in added_set or (v, u) in added_set:
                        continue
                    added_set.add((u, v))

                i += 1

        # final adversarial adjacency
        try:
            self.adj_adversary = SparseTensor.from_edge_index(edge_index=self.edge_index,
                                                              sparse_sizes=(self.n, self.n)).coalesce().detach()
        except Exception:
            # fallback: keep original adj
            self.adj_adversary = self.adj

    def _construct_modified_edges(self):
        # get subgraph around targets
        sub_nodes, sub_edges, *_ = k_hop_subgraph(self.attacking_targets.to(self.device), 2, self.edge_index)
        sub_edges = sub_edges[:, sub_edges[0] < sub_edges[1]]

        # neighbors: try adjacency -> numpy on CPU
        try:
            sp = self.adj[self.attacking_targets.to(self.device)].to_scipy(layout='csr')
            neighbors = sp.nonzero()[1]
            neighbors = torch.as_tensor(neighbors, dtype=torch.long)
        except Exception:
            # fallback via edge_index CPU
            ei_cpu = self.pyg_data.edge_index.cpu().numpy()
            targets_np = self.attacking_targets.cpu().numpy()
            neighbors = np.unique(ei_cpu[1][np.isin(ei_cpu[0], targets_np)])
            neighbors = torch.as_tensor(neighbors, dtype=torch.long)

        # collect anchors by label (CPU)
        anchors = []
        type_set = set(self.anchor_labels.cpu().tolist())
        for node_type in type_set:
            anchors.extend(torch.where(self.labels.cpu() == node_type)[0].tolist())
        anchors = np.array(anchors, dtype=np.int64)
        # remove neighbors (use numpy on CPU)
        anchors = np.setdiff1d(anchors, neighbors.cpu().numpy(), assume_unique=False)

        anchors_tensor = torch.as_tensor(anchors, dtype=torch.long, device=self.device)

        (edge_index, non_edge_index, self_loop, edges_all,
         edge_weight, non_edge_weight, self_loop_weight) = self._gen_edges(anchors_tensor, sub_nodes, sub_edges)

        weights = torch.cat([edge_weight, edge_weight,
                             non_edge_weight, non_edge_weight,
                             self_loop_weight], dim=-1)

        k = max(1, int(self.influ_ratio * max(1, anchors.shape[0])))

        add_gradient = self._compute_gradient(edges_all, weights, (non_edge_weight, ))[0]
        _, topk_nodes = torch.topk(add_gradient, k=k, sorted=False)

        non_edge_cols = non_edge_index[1].cpu().numpy()
        selected_cols = non_edge_cols[topk_nodes.cpu().numpy()]
        anchors_np2 = np.unique(selected_cols)

        anchors_tensor2 = torch.as_tensor(anchors_np2, dtype=torch.long, device=self.device)

        # regenerate edges with anchors_tensor2
        del edge_index, non_edge_index, self_loop, edges_all
        del edge_weight, non_edge_weight, self_loop_weight
        torch.cuda.empty_cache()

        (edge_index, non_edge_index, self_loop, edges_all,
         edge_weight, non_edge_weight, self_loop_weight) = self._gen_edges(anchors_tensor2, sub_nodes, sub_edges)

        return (
            edge_index, non_edge_index, self_loop, edges_all,
            edge_weight, non_edge_weight, self_loop_weight
        )

    def get_modified_adj(self):
        return SparseTensor.from_edge_index(edge_index=self.edge_index, sparse_sizes=(self.n, self.n)).coalesce().detach()

    def _targets_subgraph(self):
        sub_nodes, sub_edges, *_ = k_hop_subgraph(self.attacking_targets.to(self.device), 2, self.edge_index)
        sub_edges = sub_edges[:, sub_edges[0] < sub_edges[1]]
        return sub_nodes.cpu(), sub_edges.cpu()

    def _targets_neighbors(self):
        # best-effort neighbor retrieval; returns CPU tensor
        try:
            sp = self.adj[self.attacking_targets.to(self.device)].to_scipy(layout='csr')
            neigh = sp.nonzero()[1]
            return torch.as_tensor(neigh, dtype=torch.long)
        except Exception:
            ei = self.pyg_data.edge_index.cpu().numpy()
            targets_np = self.attacking_targets.cpu().numpy()
            neighs = np.unique(ei[1][np.isin(ei[0], targets_np)])
            return torch.as_tensor(neighs, dtype=torch.long)

    def _gen_edges(self, anchors, sub_nodes, sub_edges):
        anchors_cpu = anchors.cpu().numpy()
        targets_cpu = self.attacking_targets.cpu().numpy()

        row = np.repeat(targets_cpu, len(anchors_cpu))
        col = np.tile(anchors_cpu, targets_cpu.shape[0])

        non_edges = np.row_stack([row, col]).astype(np.int64)

        try:
            sub_nodes_cpu = sub_nodes.cpu().numpy()
        except Exception:
            sub_nodes_cpu = np.array(sub_nodes, dtype=np.int64)

        unique_nodes = np.union1d(sub_nodes_cpu, anchors_cpu)

        non_edges_t = torch.as_tensor(non_edges, device=self.device, dtype=torch.long)
        unique_nodes_t = torch.as_tensor(unique_nodes, dtype=torch.long, device=self.device)

        self_loop = unique_nodes_t.repeat((2, 1))

        if not torch.is_tensor(sub_edges):
            sub_edges = torch.as_tensor(sub_edges, dtype=torch.long, device=self.device)
        else:
            try:
                sub_edges = sub_edges.to(self.device)
            except Exception:
                pass

        edges_all = torch.cat([
            sub_edges, sub_edges[[1, 0]],
            non_edges_t, non_edges_t[[1, 0]],
            self_loop.to(self.device),
        ], dim=1)

        edge_weight = torch.ones(sub_edges.size(1), device=self.device).requires_grad_(True)
        non_edge_weight = torch.zeros(non_edges_t.size(1), device=self.device).requires_grad_(True)
        self_loop_weight = torch.ones(self_loop.size(1), device=self.device)

        return (
            sub_edges, non_edges_t, self_loop, edges_all,
            edge_weight, non_edge_weight, self_loop_weight
        )

    def _compute_gradient(self, edges_all, weights, inputs, target_weight=None):
        inputs = (inputs,) if isinstance(inputs, torch.Tensor) else tuple(inputs)
        if target_weight is not None:
            inputs = inputs + (target_weight, )
        logit = self._calc_logit(edges_all, weights)
        loss = self._calc_loss(logit, target_weight=target_weight)
        gradients = torch.autograd.grad(loss, inputs, create_graph=False)
        return gradients

    def _calc_logit(self, edges_all, weights_all):
        edge_index = torch.cat([self.edge_index, edges_all], dim=-1)

        edge_weight = torch.cat([
            torch.ones(self.edge_index.size(1), dtype=torch.float32, device=self.device),
            weights_all.to(self.device)
        ], dim=-1)

        edge_index, edge_weight = coalesce(edge_index, edge_weight, m=self.n, n=self.n, op='sum')
        mod_adj_t = SparseTensor.from_edge_index(edge_index, edge_weight, (self.n, self.n))
        logit = self.attacked_model.forward(self.x, mod_adj_t, edge_weight)
        return logit

    def _calc_loss(self, logit, eps=5.0, target_weight=None):
        loss = None
        targets = self.attacking_targets.to(self.device)
        labels = self.labels[targets]
        if self.loss_type == 'CW':
            logit_s = F.log_softmax(logit / eps, dim=1)
            loss = F.nll_loss(logit_s[targets], labels) - \
                   F.nll_loss(logit_s[targets], self.anchor_labels)
        elif self.loss_type == 'CE':
            loss = F.cross_entropy(logit[targets], labels)
        elif self.loss_type == 'MCE':
            target_preds = logit[targets].argmax(1)
            not_flipped = target_preds == labels
            loss = F.cross_entropy(logit[targets][not_flipped], labels[not_flipped])
        elif self.loss_type == 'MCW':
            target_preds = logit[targets].argmax(1)
            logit_l = F.log_softmax(logit, dim=1)
            not_flipped = target_preds == labels
            loss = F.nll_loss(logit_l[targets][not_flipped], labels[not_flipped]) - \
                   F.nll_loss(logit_l[targets][not_flipped], self.anchor_labels[not_flipped])
        # --- 鍦?attackers/pga.py 鐨?_calc_loss() 涓紝鏇挎崲 tanhMargin 涓?tanhMarginMCE 鍒嗘敮 ---

        elif self.loss_type == 'tanhMargin':
            target_preds = logit[targets].argmax(1)
            not_flipped = target_preds == labels
            logit_safe = logit[targets][not_flipped]
            if logit_safe.size(0) == 0:
                return torch.tensor(0., device=logit.device, requires_grad=True)
            idx = torch.arange(logit_safe.size(0), device=logit_safe.device)
            margin_safe = logit_safe[idx, labels[not_flipped]] - logit_safe[idx, self.anchor_labels[not_flipped]]
            loss = torch.tanh(-margin_safe).mean()

        elif self.loss_type.startswith('tanhMarginMCE-'):
            alpha = float(self.loss_type.split('-')[-1])
            target_preds = logit[targets].argmax(1)
            not_flipped = target_preds == labels
            logit_safe = logit[targets][not_flipped]
            if logit_safe.size(0) == 0:
                return torch.tensor(0., device=logit.device, requires_grad=True)
            idx = torch.arange(logit_safe.size(0), device=logit_safe.device)
            margin_safe = logit_safe[idx, labels[not_flipped]] - logit_safe[idx, self.anchor_labels[not_flipped]]
            ce_part = F.cross_entropy(logit[targets][not_flipped], labels[not_flipped], reduction='none')
            loss = alpha * torch.tanh(-margin_safe) + (1 - alpha) * ce_part
            if target_weight is not None:
                loss = target_weight[not_flipped] * loss
            loss = loss.mean()



class PoisonPGA(PGA):

    def __init__(self,
                 attack_config, pyg_data,
                 model, device, logger, **kwargs):
        super(PoisonPGA, self).__init__(attack_config, pyg_data, model, device, logger, **kwargs)

        self.surrogate = type(self.attacked_model)(
            self.attacked_model.config, pyg_data, device, logger,
            with_relu=False)
        try:
            self.surrogate = self.surrogate.to(self.device)
        except Exception:
            pass

    def inner_train(self, adj_t):
        self.surrogate.fit(self.pyg_data, adj_t=adj_t, train_iters=100, verbose=False)

    def _calc_logit(self, edges_all, weights_all):
        edge_index = torch.cat([self.edge_index, edges_all], dim=-1)

        edge_weight = torch.cat([
            torch.ones(self.edge_index.size(1), dtype=torch.float32, device=self.device),
            weights_all.to(self.device)
        ], dim=-1)

        edge_index, edge_weight = coalesce(edge_index, edge_weight, m=self.n, n=self.n, op='sum')
        mod_adj_t = SparseTensor.from_edge_index(edge_index, edge_weight, (self.n, self.n))
        logit = self.surrogate.forward(self.x, mod_adj_t, edge_weight)
        return logit

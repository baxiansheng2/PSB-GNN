# attackers/pga_wrapper.py
# -*- coding: utf-8 -*-
from __future__ import annotations
import os
import logging
from typing import Any, Optional

import torch
from torch import Tensor
import numpy as np
from torch_sparse import SparseTensor

# 尝试导入默认 PGA，如果没有也无所谓，只要传入 attacker_class 即可
try:
    from .pga import PGA as DefaultPGA  # noqa: F401
except ImportError:
    DefaultPGA = None


def _get_logger(logger: Optional[logging.Logger]) -> logging.Logger:
    if logger is not None:
        return logger
    logger = logging.getLogger("attackers.pga_wrapper")
    if not logger.handlers:
        handler = logging.StreamHandler()
        fmt = logging.Formatter("[%(asctime)s][%(name)s][%(levelname)s] %(message)s")
        handler.setFormatter(fmt)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger

def _edge_index_to_sparse(edge_index: Tensor,
                          edge_weight: Optional[Tensor],
                          num_nodes: int) -> SparseTensor:
    if not isinstance(edge_index, Tensor):
        edge_index = torch.as_tensor(edge_index, dtype=torch.long)
    
    if edge_weight is None:
        edge_weight = torch.ones(edge_index.size(1), dtype=torch.float32, device=edge_index.device)

    st = SparseTensor.from_edge_index(edge_index=edge_index.cpu(),
                                      value=edge_weight.cpu(),
                                      sparse_sizes=(num_nodes, num_nodes))
    return st.coalesce()


class PGAAttackerWrapper:
    """
    适配器模式：
    负责连接 train.py (期望显式返回 adj) 和 pga.py (可能只修改内部状态)。
    """

    def __init__(
        self,
        model: torch.nn.Module,
        pyg_data: Any,
        device: torch.device,
        logger: Optional[logging.Logger] = None,
        attacker_class: Optional[type] = None,
        **kwargs,
    ) -> None:
        
        self.logger = _get_logger(logger)
        self.model = model
        self.pyg_data = pyg_data
        self.device = device

        # 1. 处理配置
        cfg = kwargs.get("attack_config") or kwargs.get("config") or {}
        self.attack_config = cfg

        # 2. 记录图的基本信息（用于兜底）
        self.num_nodes = int(getattr(self.pyg_data, "num_nodes", 0) or getattr(self.pyg_data, "x").size(0))
        
        # 3. 实例化攻击器
        AClass = attacker_class or DefaultPGA
        if AClass is None:
            raise ImportError("Cannot import PGA class and no attacker_class provided.")

        self.logger.info(f"[ATTACKER] Initializing {AClass.__name__}")

        # 直接实例化，如果报错（如缺参数），让它在这里就抛出异常，不要掩盖。
        try:
            self.attacker = AClass(
                attack_config=cfg,
                pyg_data=self.pyg_data,
                model=self.model,
                device=self.device,
                logger=self.logger
            )
        except TypeError as e:
            # 兼容某些旧版 PGA 签名的尝试（如果你的 PGA 是标准版，通常不需要这个）
            self.logger.warning(f"[ATTACKER] Standard init failed ({e}), trying simplified init...")
            self.attacker = AClass(model, pyg_data, device)

    def generate(self, n_perturbations: int, data: Any = None, y: Optional[Tensor] = None) -> SparseTensor:
        """
        统一接口：执行攻击并返回 SparseTensor。
        """
        if data is None:
            data = self.pyg_data
        if y is None and hasattr(data, "y"):
            y = data.y

        # 1. 调用底层攻击逻辑
        out = None
        if hasattr(self.attacker, "_attack"):
            # PGA 通常用 _attack
            out = self.attacker._attack(n_perturbations)
        elif hasattr(self.attacker, "attack"):
            out = self.attacker.attack(n_perturbations)
        else:
            raise AttributeError(f"Attacker {type(self.attacker)} has no _attack() or attack() method.")

        # 2. 适配返回值
        # 情况 A: 攻击器显式返回了结果 (我们之前想改的方式，但为了不改基线，可能不走这条路)
        if out is not None:
            return self._to_sparse(out)

        # 情况 B: 攻击器返回 None，但修改了内部 self.adj_adversary (这是标准 PGA 的行为)
        if hasattr(self.attacker, 'adj_adversary') and self.attacker.adj_adversary is not None:
            return self._to_sparse(self.attacker.adj_adversary)
            
        # 情况 C: 兜底（失败）
        self.logger.warning("[ATTACKER] generate returned None and no adj_adversary found. Returning original adj.")
        if hasattr(self.pyg_data, 'adj_t'):
             return self.pyg_data.adj_t
        return _edge_index_to_sparse(self.pyg_data.edge_index, None, self.num_nodes)

    def _to_sparse(self, val: Any) -> SparseTensor:
        """辅助函数：将各种乱七八糟的输出转为 SparseTensor"""
        if isinstance(val, SparseTensor):
            return val.coalesce()
        
        if isinstance(val, (tuple, list)):
            # 假设是 (edge_index, edge_weight)
            ew = val[1] if len(val) > 1 else None
            return _edge_index_to_sparse(val[0], ew, self.num_nodes)
            
        return val # 如果实在不知道是什么，原样返回（可能会报错，但在报错栈里能看到类型）
import os
import os.path as osp
import sys
import argparse
import yaml
from yaml import SafeLoader
import time
import shutil
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import traceback
from copy import deepcopy

# 保证项目根目录在 sys.path 中
sys.path.insert(0, os.path.abspath('../'))

from common.utils import load_data, get_logger
# 引用你的 EGND 模型
from models.EGNDgcn import GCN as EGNDGCN

# 尝试导入 torch_sparse
try:
    from torch_sparse import SparseTensor
except ImportError:
    SparseTensor = None

# ------------------------------ Helper Functions ------------------------------

def _set_global_seed(seed: int):
    """设置全局随机种子，保证可复现性"""
    import random
    os.environ['PYTHONHASHSEED'] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def build_sparse_adj(data, device):
    """构建稀疏邻接矩阵，适配 EGND 输入"""
    if hasattr(data, 'adj_t') and isinstance(data.adj_t, SparseTensor):
        return data.adj_t.to(device)
    
    # Fallback to edge_index
    edge_index = data.edge_index.to(device)
    num_nodes = data.num_nodes
    if edge_index.size(1) == 0:
        return SparseTensor(sparse_sizes=(num_nodes, num_nodes)).to(device)
        
    val = torch.ones(edge_index.size(1), device=device)
    return SparseTensor.from_edge_index(edge_index, val, (num_nodes, num_nodes))

# ------------------------------ Configuration ------------------------------

def get_args():
    parser = argparse.ArgumentParser(description="EGND Defense Training with Distillation")
    
    # 基础配置
    parser.add_argument('--model', type=str, default='EGNDgcn')
    parser.add_argument('--dataset', type=str, default='cora', choices=['cora', 'citeseer', 'pubmed'])
    parser.add_argument('--config', type=str, default=None, help='Path to yaml config')
    parser.add_argument('--seed', type=int, default=15)
    parser.add_argument('--epochs', type=int, default=200)
    parser.add_argument('--save', type=bool, default=True)
    parser.add_argument('--device_id', type=int, default=0)
    parser.add_argument('--num_hidden', type=int, default=16, help='Hidden dimension size (Must be 16)') 
    
    # === [关键修复] 新增架构参数支持，解决 unrecognized arguments 报错 ===
    parser.add_argument('--num_layers', type=int, default=None, help='Overwrite number of layers')
    parser.add_argument('--lr', type=float, default=None, help='Overwrite learning rate')
    
    # 核心防御超参 (Distillation & Noise)
    parser.add_argument('--distill_lambda', type=float, default=2.0, help='Weight for distillation loss')
    parser.add_argument('--pni_reg', type=float, default=0.1, help='Weight for PNI regularization')
    parser.add_argument('--pni_lr', type=float, default=0.01)
    parser.add_argument('--adv_lambda', type=float, default=0.0)
    
    # Teacher Path
    parser.add_argument('--teacher_path', type=str, default=None, help="Explicit path to teacher checkpoint")
    
    args = parser.parse_args()
    return args

def get_args():
    parser = argparse.ArgumentParser(description="EGND Defense Training")
    parser.add_argument('--model', type=str, default='EGNDgcn')
    parser.add_argument('--dataset', type=str, default='cora', choices=['cora', 'citeseer', 'pubmed'])
    parser.add_argument('--config', type=str, default=None)
    parser.add_argument('--seed', type=int, default=15)
    parser.add_argument('--epochs', type=int, default=200)
    parser.add_argument('--save', type=bool, default=True)
    parser.add_argument('--device_id', type=int, default=0)
    parser.add_argument('--num_hidden', type=int, default=16) 
    
    # 架构微调
    parser.add_argument('--num_layers', type=int, default=None)
    parser.add_argument('--lr', type=float, default=None)
    parser.add_argument('--dropout', type=float, default=None, help='Overwrite dropout rate') # <--- 新增
    
    # 防御参数
    parser.add_argument('--distill_lambda', type=float, default=2.0)
    parser.add_argument('--pni_reg', type=float, default=0.1)
    parser.add_argument('--pni_lr', type=float, default=0.01)
    parser.add_argument('--adv_lambda', type=float, default=0.0)
    parser.add_argument('--teacher_path', type=str, default=None)

    # 推理参数
    parser.add_argument('--bias', type=float, default=None)
    parser.add_argument('--threshold', type=float, default=None)

     # === [新增] 显式传入 NPY 文件的绝对路径 ===
    parser.add_argument('--pni_path', type=str, default=None, help="Absolute path to the edge importance NPY file") 

        # === [新增] NPY 映射参数 ===
    parser.add_argument('--lambda_base', type=float, default=0.55, help="Base value for NPY mapping")
    parser.add_argument('--lambda_range', type=float, default=0.45, help="Range value for NPY mapping")
    
    args = parser.parse_args()
    return args

def load_config(args):
    if args.config:
        config_path = args.config
    else:
        config_path = osp.join(osp.dirname(__file__), 'configs', f'{args.dataset}.yaml')
    
    config = {}
    if osp.exists(config_path):
        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.load(f, Loader=SafeLoader) or {}
        if args.dataset in config:
            config = config[args.dataset]
    
    # 覆盖参数
    config['seed'] = args.seed
    config['pni_reg'] = args.pni_reg
    config['distill_lambda'] = args.distill_lambda
    config['adv_lambda'] = args.adv_lambda
    config['epochs'] = args.epochs
    config['num_hidden'] = args.num_hidden 
    
    if args.num_layers is not None: config['num_layers'] = args.num_layers
    if args.lr is not None: config['lr'] = args.lr
    if args.dropout is not None: config['dropout'] = args.dropout # <--- 新增
    
    # 注入推理参数
    if args.bias is not None: config['bias'] = args.bias
    if args.threshold is not None: config['threshold'] = args.threshold
    
    defaults = {
        'num_layers': 2, 'dropout': 0.5, 'lr': 0.01, 'weight_decay': 5e-4, 
        'patience': 100, 'noise_in_train': True, 'noise_in_eval': False, 'use_residual': True
    }
    for k, v in defaults.items():
        config.setdefault(k, v)
        
    return config
# ------------------------------ Model Builder ------------------------------

def build_model(args, config, data, device, logger, is_teacher=False, checkpoint_path=None):
    """
    构建 EGNDgcn 模型 (修复版：0.8保守映射 + 绝对路径支持)
    """
    # 1. 尝试加载 PNI 资源 (Lambda Init) - 仅针对 Student
    proj_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    res_dir = os.path.join(proj_root, 'res', args.dataset.capitalize())
    
    lambda_init = None
    if not is_teacher: 
        candidates = []
        
        # 优先检查命令行传入的绝对路径
        if hasattr(args, 'pni_path') and args.pni_path:
            candidates.append(args.pni_path)
            
        # 原有逻辑作为备选
        candidates.append(os.path.join(res_dir, '_lambda_init_full.npy'))
        candidates.append(os.path.join(res_dir, f"{args.dataset}_lambda_init_full.npy"))

        for p in candidates:
            if os.path.exists(p):
                try:
                    arr = np.load(p)
                    arr = np.nan_to_num(arr, nan=0.0, posinf=1.0, neginf=0.0)
                    lambda_init = torch.tensor(arr, dtype=torch.float32, device=device)
                    
                    val_min, val_max = lambda_init.min(), lambda_init.max()
                    denom = val_max - val_min
                    
                    if denom < 1e-6:
                        # 极差太小，退化为全1
                        lambda_init = torch.ones_like(lambda_init)
                        if logger: logger.warning(f"[RES] NPY variance too small, falling back to ONES.")
                    else:
                        # 1. 先归一化到 [0, 1] (这是必要的预处理)
                        lambda_init = (lambda_init - val_min) / denom
                        
                        # 2. 再映射到目标区间 [Base, Base + Range]
                        # === [核心修改] 使用命令行参数 ===
                        base = getattr(args, 'lambda_base', 0.5) # 使用 getattr 防止参数未定义报错
                        rng = getattr(args, 'lambda_range', 0.5)
                        lambda_init = base + rng * lambda_init
                        
                        if logger: 
                            logger.info(f"[RES] SUCCESS: Loaded lambda_init from {p}")
                            logger.info(f"[RES] Mapping Strategy: {base} + {rng} * x")
                            logger.info(f"[RES] Stats: Min={lambda_init.min():.4f}, Mean={lambda_init.mean():.4f}")
                    break 
                except Exception as e:
                    if logger: logger.warning(f"[RES] Failed to load {p}: {e}")
            else:
                if hasattr(args, 'pni_path') and args.pni_path and p == args.pni_path:
                    if logger: logger.error(f"[RES] FILE NOT FOUND: {p}")

    # 2. 实例化模型
    model_lambda = None if is_teacher else lambda_init
    model = EGNDGCN(config, data, device, logger, lambda_init=model_lambda)
    model = model.to(device)
    
    if hasattr(model, 'activate_defense'):
        model.activate_defense = False
    
    if not is_teacher and lambda_init is not None:
        model.register_buffer('edge_importance', lambda_init.clone().detach())
    
    # 3. 如果是 Teacher，冻结参数
    if is_teacher:
        for param in model.parameters():
            param.requires_grad = False
        model.eval()

    return model
# ------------------------------ Loss & Optimizer ------------------------------

def distillation_loss(student_logits, teacher_logits, temperature=1.0):
    """知识蒸馏损失 (KL Divergence)"""
    soft_targets = F.softmax(teacher_logits / temperature, dim=1)
    student_log_soft = F.log_softmax(student_logits / temperature, dim=1)
    # 乘以 T^2 保持梯度量级
    loss = F.kl_div(student_log_soft, soft_targets, reduction='batchmean') * (temperature ** 2)
    return loss

def prepare_optimizer(model, config, args, logger):
    """
    准备优化器：自动扫描并分离 PNI 参数
    """
    pni_lr = args.pni_lr
    main_lr = float(config.get('lr', 0.01))
    weight_decay = float(config.get('weight_decay', 5e-4))

    pni_params = []
    main_params = []

    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        # 只要名字里带 edge_pni，就归为 PNI 组
        if 'edge_pni' in name:
            pni_params.append(param)
        else:
            main_params.append(param)

    # 参数组
    param_groups = [{'params': main_params, 'lr': main_lr, 'weight_decay': weight_decay}]
    if len(pni_params) > 0:
        # PNI 参数通常不加 weight_decay
        param_groups.append({'params': pni_params, 'lr': pni_lr, 'weight_decay': 0.0})
        logger.info(f"[OPT] Detected {len(pni_params)} PNI trainable tensors.")
    
    return torch.optim.Adam(param_groups)
# ------------------------------ Training Logic (Core Fix) ------------------------------

def train_distill(student, teacher, data, config, args, logger):
    """
    执行单次蒸馏训练 
    [修复版]: 移除了动态归一化逻辑，强制 lambda 绝对值逼近可解释性目标
    """
    device = next(student.parameters()).device
    adj = build_sparse_adj(data, device)
    train_mask = data.train_mask.bool()
    val_mask = data.val_mask.bool()
    test_mask = data.test_mask.bool()
    labels = data.y

    # 预计算 Teacher 的 Logits
    teacher_logits = None
    if teacher:
        teacher.eval()
        with torch.no_grad():
            teacher_logits = teacher.forward(data.x, adj)
            
    optimizer = prepare_optimizer(student, config, args, logger)
    
    # 记录最佳验证集状态
    best_val_acc = 0.0
    best_state = None
    
    epochs = config.get('epochs', 200)
    patience = config.get('patience', 100)
    patience_counter = 0
    
    # 提前获取 Target (Edge Importance)
    # 注意：这个 target 已经在 build_model 里经过了 [0.8, 1.0] 或 [0.5, 1.0] 的安全映射
    target_imp = None
    if hasattr(student, 'edge_importance'):
        target_imp = student.edge_importance.detach()

    for epoch in range(1, epochs + 1):
        student.train()
        optimizer.zero_grad()
        
        # Forward
        student_out = student.forward(data.x, adj)
        
        # 1. Classification Loss
        loss_cls = F.nll_loss(student_out[train_mask], labels[train_mask])
        
        # 2. Distillation Loss
        loss_distill = torch.tensor(0.0, device=device)
        if teacher_logits is not None and args.distill_lambda > 0:
            loss_distill = distillation_loss(student_out, teacher_logits, temperature=1.0)
            
        # 3. PNI Regularization Loss (FIXED: Absolute Guidance)
        loss_pni = torch.tensor(0.0, device=device)
        current_lam = None
        
        if hasattr(student, 'get_pni_tensor'):
            current_lam = student.get_pni_tensor()
            
        if args.pni_reg > 0 and current_lam is not None and target_imp is not None:
            # 维度对齐
            n_elem = min(current_lam.numel(), target_imp.numel())
            
            lam_flat = current_lam.view(-1)[:n_elem]
            tgt_flat = target_imp.view(-1)[:n_elem]
            
            loss_pni = F.mse_loss(lam_flat, tgt_flat)

        total_loss = loss_cls + (args.distill_lambda * loss_distill) + (args.pni_reg * loss_pni)
        
        total_loss.backward()
        optimizer.step()
        
        # PNI Sanitize
        if current_lam is not None:
             with torch.no_grad():
                 current_lam.data.clamp_(0.0, 1.0)

        # Validation
        student.eval()
        with torch.no_grad():
            val_out = student.forward(data.x, adj)
            val_pred = val_out.argmax(dim=1)
            val_acc = (val_pred[val_mask] == labels[val_mask]).float().mean().item()
            
            if val_acc > best_val_acc:
                best_val_acc = val_acc
                best_state = {k: v.cpu().clone() for k, v in student.state_dict().items()}
                patience_counter = 0
            else:
                patience_counter += 1
                
        if patience_counter >= patience:
            break

    # 加载最佳模型
    if best_state is not None:
        student.load_state_dict(best_state)
    
    # 最终测试集评估
    student.eval()
    test_out = student.forward(data.x, adj)
    test_pred = test_out.argmax(dim=1)
    test_acc = (test_pred[test_mask] == labels[test_mask]).float().mean().item()
    
    return test_acc
# ------------------------------ Main Entry ------------------------------
# ------------------------------ Main Entry (Fixed) ------------------------------

def main():
    args = get_args()
    
    # 1. Logger Setup
    if not os.path.exists('./logs'):
        os.makedirs('./logs')
    log_path = f"./logs/train_distill_{args.dataset}.log"
    logger = get_logger(log_path)
    
    logger.info(f"Arguments: {args}")
    
    # 2. Environment Setup
    device = torch.device(f'cuda:{args.device_id}' if torch.cuda.is_available() else 'cpu')
    logger.info(f"Device: {device}")
    
    # 3. Load Config & Data (Student Config)
    student_config = load_config(args)
    data = load_data(args.dataset)
    data = data.to(device)
    
    # 4. 准备 Teacher 路径 & 配置
    if args.teacher_path:
        teacher_path = args.teacher_path
    else:
        teacher_path = f"./models/gcn-{args.dataset}.pth"
    
    if not os.path.exists(teacher_path):
        logger.error(f"!!! TEACHER NOT FOUND: {teacher_path} !!!")
        raise FileNotFoundError(f"Teacher missing at {teacher_path}")
    
    logger.info(f"[CORRECT LOAD] Loading Teacher Checkpoint from: {teacher_path}")
    
    # 预读取 Teacher Checkpoint
    try:
        teacher_ckpt = torch.load(teacher_path, map_location=device)
        
        # === [CRITICAL FIX] 从 Checkpoint 中提取教师原始配置 ===
        # 老师是 2层，学生是 4层，不能混用 config！
        if 'config' in teacher_ckpt:
            teacher_config = teacher_ckpt['config']
            logger.info(f"Loaded Teacher Config from Checkpoint: Layers={teacher_config.get('num_layers')}, Hidden={teacher_config.get('num_hidden')}")
        else:
            # 兜底：如果没存 config，就默认是 2层标准 GCN
            logger.warning("Teacher Checkpoint has no config! Fallback to default 2-layer config.")
            teacher_config = deepcopy(student_config)
            teacher_config['num_layers'] = 2 

        # 提取权重列表
        if 'state_dicts' in teacher_ckpt:
            teacher_sds = teacher_ckpt['state_dicts']
        elif 'state_dict' in teacher_ckpt:
            teacher_sds = [teacher_ckpt['state_dict']]
        else:
            teacher_sds = [teacher_ckpt]

        if not isinstance(teacher_sds, list):
            teacher_sds = [teacher_sds]
            
    except Exception as e:
        logger.error(f"Failed to load teacher file: {e}")
        raise e

    # 5. 开始训练循环 (5 Runs)
    n_running = 5 
    student_state_dicts = [] 
    test_acc_list = []      
    base_seed = args.seed
    
    # 日志显示学生的层数
    logger.info(f"Start Training Loop for {n_running} runs (Student Layers={student_config['num_layers']}, LR={student_config['lr']})...")

    for i in range(n_running):
        current_seed = base_seed + i
        _set_global_seed(current_seed)
        logger.info(f"\n>>> Run {i+1}/{n_running} (Seed={current_seed})")
        
        # A. 构建并加载 Teacher (使用 teacher_config)
        # 注意：这里传入的是 teacher_config，保证它是 2 层的
        teacher = build_model(args, teacher_config, data, device, logger, is_teacher=True, checkpoint_path=teacher_path)
        
        # 智能选择 Teacher 参数
        if len(teacher_sds) >= n_running:
            target_sd = teacher_sds[i]
        else:
            target_sd = teacher_sds[0]
            
        # 处理键名映射 (兼容性处理)
        new_sd = {}
        teacher_model_keys = teacher.state_dict().keys()
        for k, v in target_sd.items():
            new_k = k
            if 'gc1' in k: new_k = k.replace('gc1', 'layers.0')
            elif 'gc2' in k: new_k = k.replace('gc2', 'layers.1')
            if new_k.startswith('module.'): new_k = new_k[7:]
            if new_k in teacher_model_keys:
                new_sd[new_k] = v
        
        teacher.load_state_dict(new_sd, strict=False)
        teacher.eval() 
        
        # B. 构建并训练 Student (使用 student_config)
        # 这里传入的是 student_config，保证它是 4 层的
        student = build_model(args, student_config, data, device, logger, is_teacher=False)
        
        test_acc = train_distill(student, teacher, data, student_config, args, logger)
        
        logger.info(f"Run {i+1} Finished. Test Acc: {test_acc*100:.2f}%")
        
        test_acc_list.append(test_acc)
        student_state_dicts.append(deepcopy(student.cpu().state_dict()))

    # 6. 汇总与保存
    mean_acc = np.mean(test_acc_list) * 100
    std_acc = np.std(test_acc_list) * 100
    
    logger.info(f"\n" + "="*40)
    logger.info(f"Final Performance over {n_running} runs: {mean_acc:.2f} ± {std_acc:.2f}")
    logger.info("="*40)

    if args.save:
        if not os.path.exists('./models'):
            os.makedirs('./models')
        
        save_path = f"./models/egnd-{args.dataset}.pth"
        
        torch.save({
            'state_dicts': student_state_dicts,
            'config': student_config,
            'performance': f"{mean_acc:.2f}±{std_acc:.2f}"
        }, save_path)
        logger.info(f"Saved all {n_running} runs to {save_path}")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print("="*30 + " ERROR TRACEBACK " + "="*30)
        traceback.print_exc() 
        print("="*80)
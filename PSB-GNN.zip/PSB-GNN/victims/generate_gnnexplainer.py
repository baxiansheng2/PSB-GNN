import os
import sys
import argparse
import torch
import numpy as np
from tqdm import tqdm
import torch.nn.functional as F

# 适配路径，确保能 import models
sys.path.insert(0, os.path.abspath('../'))

from common.utils import load_data, get_logger
from models.EGNDgcn import GCN as EGNDGCN
from torch_geometric.explain import Explainer, GNNExplainer, ModelConfig

def get_args():
    parser = argparse.ArgumentParser(description="Generate Edge Importance using GNNExplainer")
    parser.add_argument('--dataset', type=str, default='cora', choices=['cora', 'citeseer', 'pubmed'])
    parser.add_argument('--teacher_path', type=str, required=True, help="Path to the pretrained Teacher GCN")
    parser.add_argument('--device_id', type=int, default=0)
    parser.add_argument('--num_hidden', type=int, default=16)
    parser.add_argument('--num_layers', type=int, default=2) 
    
    # 解释器参数
    parser.add_argument('--epochs', type=int, default=200, help="Optimization epochs per node")
    parser.add_argument('--sample_ratio', type=float, default=1.0, help="Ratio of nodes to explain")
    
    args = parser.parse_args()
    return args

def calculate_statistics(edge_index, edge_scores, labels, dataset_name):
    """
    [新增功能] 原地计算统计数据，确保索引绝对对齐
    """
    print(f"\n=== [In-Place Statistics] Analyzing {dataset_name} ===")
    
    src = edge_index[0].cpu().numpy()
    dst = edge_index[1].cpu().numpy()
    labels = labels.cpu().numpy()
    
    intra_scores = []
    inter_scores = []
    
    num_edges = edge_index.shape[1]
    
    # 遍历所有边进行分类
    for i in range(num_edges):
        u, v = src[i], dst[i]
        
        # 跳过自环
        if u == v: continue
            
        score = edge_scores[i]
        
        if labels[u] == labels[v]:
            intra_scores.append(score)
        else:
            inter_scores.append(score)
            
    intra = np.array(intra_scores)
    inter = np.array(inter_scores)
    
    print(f"  > Total Edges: {num_edges}")
    print(f"  > Intra-class Edges: {len(intra)}")
    print(f"    Mean: {intra.mean():.4f} | Median: {np.median(intra):.4f} | Std: {intra.std():.4f}")
    
    print(f"  > Inter-class Edges: {len(inter)}")
    print(f"    Mean: {inter.mean():.4f} | Median: {np.median(inter):.4f} | Std: {inter.std():.4f}")
    
    gap = intra.mean() - inter.mean()
    print(f"  > *** GAP (Intra - Inter): {gap:.4f} ***")
    
    if gap > 0.05:
        print("  [结论] 验证成功：解释器显著倾向于保留同类边。")
    else:
        print("  [结论] 信号微弱：可能是解释器未收敛或模型本身性能较差。")
    print("=======================================================\n")

def main():
    args = get_args()
    device = torch.device(f'cuda:{args.device_id}' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")

    # 1. 加载数据
    print(f"Loading dataset: {args.dataset}...")
    data = load_data(args.dataset).to(device)
    
    # 2. 加载教师模型
    print(f"Loading Teacher from {args.teacher_path}...")
    
    config = {
        'num_layers': args.num_layers,
        'num_hidden': args.num_hidden,
        'dropout': 0.5, 
        'use_residual': False 
    }
    
    model = EGNDGCN(config, data, device, None, lambda_init=None)
    
    if not os.path.exists(args.teacher_path):
        raise FileNotFoundError(f"Teacher file not found: {args.teacher_path}")
        
    checkpoint = torch.load(args.teacher_path, map_location=device)
    # 兼容不同的 checkpoint 格式
    if isinstance(checkpoint, dict):
        if 'state_dicts' in checkpoint:
            state_dict = checkpoint['state_dicts'][0]
        elif 'state_dict' in checkpoint:
            state_dict = checkpoint['state_dict']
        else:
            state_dict = checkpoint
    else:
        state_dict = checkpoint
    
    # 权重键名适配
    new_sd = {}
    for k, v in state_dict.items():
        new_k = k
        if 'gc1' in k: new_k = k.replace('gc1', 'layers.0')
        elif 'gc2' in k: new_k = k.replace('gc2', 'layers.1')
        if new_k.startswith('module.'): new_k = new_k[7:]
        # 移除 input_proj 相关权重（如果 Student 已移除）
        if 'input_proj' in new_k and not hasattr(model, 'input_proj'):
            continue
        if new_k in model.state_dict():
            new_sd[new_k] = v
            
    model.load_state_dict(new_sd, strict=False)
    model.eval()
    model = model.to(device)
    print("Teacher model loaded successfully.")

    # 3. 配置 GNNExplainer
    print("Initializing GNNExplainer...")
    explainer = Explainer(
        model=model,
        algorithm=GNNExplainer(epochs=args.epochs),
        explanation_type='model',
        node_mask_type=None,
        edge_mask_type='object',
        model_config=ModelConfig(
            mode='multiclass_classification',
            task_level='node',
            return_type='log_probs',
        ),
    )

    # 4. 采样解释
# 4. 采样解释 (修改版：覆盖全图节点，包括 Train/Val/Test)
    # 在 Transductive 设定下，结构是可见的，我们解释 Teacher 的预测行为
    all_nodes = list(range(data.num_nodes))
    
    if args.sample_ratio < 1.0:
        sample_size = int(len(all_nodes) * args.sample_ratio)
        sampled_nodes = random.sample(all_nodes, sample_size)
    else:
        # 当 ratio=1.0 时，解释全图 2708 个节点
        sampled_nodes = all_nodes
        
    print(f"Explaining {len(sampled_nodes)} nodes to aggregate edge importance...")

    num_edges = data.edge_index.size(1)
    global_edge_mask = torch.zeros(num_edges, device=device)
    edge_hit_counts = torch.zeros(num_edges, device=device)

    for node_idx in tqdm(sampled_nodes):
        # 解释单个节点
        explanation = explainer(data.x, data.edge_index, index=node_idx)
        
        if explanation.edge_mask is not None:
            mask = explanation.edge_mask.detach()
            mask = torch.relu(mask) 
            global_edge_mask += mask
            edge_hit_counts += (mask > 0).float()

    # 5. 计算平均重要性
    edge_hit_counts[edge_hit_counts == 0] = 1.0
    final_importance = global_edge_mask / edge_hit_counts
    final_importance_np = final_importance.cpu().numpy()
    
    # 归一化
    if final_importance_np.max() > 0:
        final_importance_np = final_importance_np / final_importance_np.max()

    print(f"Generated scores. Min={final_importance_np.min():.4f}, Max={final_importance_np.max():.4f}")

    # === [关键新增] 立即执行统计验证 ===
    calculate_statistics(data.edge_index, final_importance_np, data.y, args.dataset)

    # 6. 保存
    res_dir = os.path.join(os.path.abspath('../'), 'res', args.dataset.capitalize())
    if not os.path.exists(res_dir):
        os.makedirs(res_dir)
        
    save_path = os.path.join(res_dir, 'gnnexplainer_init_full.npy')
    np.save(save_path, final_importance_np)
    
    print(f"\n[SUCCESS] Saved GNNExplainer mask to: {save_path}")

if __name__ == '__main__':
    import random
    main()
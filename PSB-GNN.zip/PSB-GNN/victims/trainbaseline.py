import os.path as osp
import os
import sys
sys.path.insert(0, os.path.abspath('../'))

import argparse
import yaml
from yaml import SafeLoader
import numpy as np
import torch
from copy import deepcopy

from common.utils import *
from models import model_map
import time

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str, default='gcn')
    parser.add_argument('--gpu_id', type=int, default=0)
    parser.add_argument('--logger_level', type=int, default=0)
    parser.add_argument('--dataset', type=str, default='cora', choices=['cora', 'citeseer', 'pubmed', 'cora_ml'])
    parser.add_argument('--save', type=bool, default=True) # 默认开启保存
    parser.add_argument('--save_name', type=str, default=None, help="Custom filename for the checkpoint")
    parser.add_argument('--seed', type=int, default=None, help="Overwrite config seed")
    # === 新增：支持命令行修改 Hidden Size ===
    parser.add_argument('--num_hidden', type=int, default=None, help="Overwrite hidden dimension")

    args = parser.parse_args()

    assert args.model in model_map
    assert args.gpu_id in range(0, 4)
    assert args.logger_level in [0, 1, 2]

    config_file = osp.join(osp.expanduser('./configs'), args.model+'.yaml')
    config = yaml.load(open(config_file, encoding='utf-8'), Loader=SafeLoader)[args.dataset]
    
    # === 覆盖配置 ===
    if args.seed is not None:
        config['seed'] = args.seed
    if args.num_hidden is not None:
        config['num_hidden'] = args.num_hidden
        print(f"[Config Override] num_hidden set to {args.num_hidden}")

    logger_filename = "./logs/" + args.model + '-' + args.dataset + '.log'
    logger_name = 'model_train'
    logger = get_logger(logger_filename, level=args.logger_level, name=logger_name)

    logger.info(config)

    device = get_device(args.gpu_id)
    logger.info(f"MODEL NAME: {args.model}")
    logger.info(f"DATASET: {args.dataset}")
    logger.info(f"DEVICE: {device}")
    
    seed = config['seed']
    freeze_seed(seed)
    
    pyg_data = load_data(name=args.dataset)
    model_func = model_map[args.model]

    # 构建模型
    model = model_func(config=config, pyg_data=pyg_data, device=device, logger=logger)
    model = model.to(device)
    
    state_dicts = []
    statistics = []
    
    # 运行 5 次以获取统计数据
    for i in range(5):
        current_run_seed = seed + i
        freeze_seed(current_run_seed)
        logger.debug(f"Run {i+1:02d} (Seed {current_run_seed}) ============================================================")
                    
        model.fit(pyg_data, verbose=True)
        
        acc = model.test(pyg_data.test_mask)
        statistics.append(acc)
        state_dicts.append(deepcopy(model.cpu().state_dict()))
        model.cuda() # 移回 GPU
        
        logger.info(f"accuracy={statistics[-1]*100:.3f}")
        logger.debug(f"============================================================ Run {i+1:02d} \n\n")
    
    mean_acc = np.mean(statistics)*100
    std_acc = np.std(statistics)*100
    logger.info(f"statistics: {mean_acc:.2f}{chr(177)}{std_acc:.2f}")

    if args.save:
        save_path = "./models/"
        if not os.path.exists(save_path): os.makedirs(save_path)
        
        # 自动命名：如果是特殊维度，文件名带上维度
        if args.save_name:
            save_file = args.save_name
        else:
            dim_suffix = f"-h{args.num_hidden}" if args.num_hidden else ""
            save_file = f"{args.model.lower()}-{args.dataset}{dim_suffix}.pth"
            
        if not save_file.endswith('.pth'): save_file += '.pth'
        full_path = os.path.join(save_path, save_file)
        
        torch.save({
            'state_dicts': state_dicts,
            'config': config,
            'performance': f"{mean_acc:.2f}",
        }, full_path)
        logger.info(f"[{full_path}] Saved")

if __name__ == '__main__':
    main()
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
generate_edge_noise.py (final)
- 将 explain_node.py 输出的 trainonly_global_mask 和 train_edge_ids 映射回全局 edge_index
- 生成 lambda_init_full（与全图边一一对应），并导出带数据集前缀的文件名
- 导出分桶 CSV 和元信息
- 支持自动匹配 *_train_edge_ids.npy（避免手动重命名）
"""

import argparse
import os
import glob
import json
import numpy as np
import pandas as pd
from datetime import datetime

def find_single_or_first(pattern_dir, pattern):
    """返回第一个匹配的文件路径或 None"""
    matches = glob.glob(os.path.join(pattern_dir, pattern))
    if len(matches) == 0:
        return None
    if len(matches) > 1:
        print(f"[WARN] 找到多个匹配 ({pattern})，使用第一个: {matches[0]}")
    return matches[0]

def load_train_mask(train_mask_path):
    if not os.path.exists(train_mask_path):
        raise FileNotFoundError(f"train_mask 文件不存在: {train_mask_path}")
    arr = np.load(train_mask_path)
    return arr.astype(np.float32)

def load_train_edge_ids(train_edge_ids_path):
    if not os.path.exists(train_edge_ids_path):
        raise FileNotFoundError(f"train_edge_ids 文件不存在: {train_edge_ids_path}")
    ids = np.load(train_edge_ids_path).astype(int)
    # 可能保存成 shape (1, N)
    if ids.ndim == 2 and ids.shape[0] == 1:
        ids = ids.flatten()
    return ids

def load_edge_index(edge_index_path):
    if not os.path.exists(edge_index_path):
        raise FileNotFoundError(f"edge_index 文件不存在: {edge_index_path}")
    ei = np.load(edge_index_path)
    # Accept shapes (2, E) or (E, 2)
    if ei.ndim == 2 and ei.shape[0] == 2:
        return ei  # (2,E)
    if ei.ndim == 2 and ei.shape[1] == 2:
        return ei.T  # to (2,E)
    raise ValueError("edge_index 格式不支持，期望 (2,E) 或 (E,2) 的 numpy 数组")

def bucketize_values(vals, n_buckets):
    """对训练边的 lambda 值进行分桶（返回 buckets edges boundaries 和 bucket_idx per value）"""
    if n_buckets <= 1:
        return None, np.zeros_like(vals, dtype=int)
    # boundaries: len = n_buckets+1
    boundaries = np.quantile(vals, np.linspace(0, 1, n_buckets + 1))
    # assign bucket indices: 0 .. n_buckets-1
    # np.digitize 默认右边开，所以使用 boundaries[1:-1]
    bucket_idx = np.digitize(vals, boundaries[1:-1], right=True)
    bucket_idx = np.clip(bucket_idx, 0, max(0, n_buckets - 1))
    return boundaries, bucket_idx

def build_lambda_full(train_mask_path, edge_index_path, out_dir,
                      num_buckets=5, dataset_name=None, export_csv=True, export_meta=True):
    """
    主函数：构建全图 lambda 向量并保存
    - train_mask_path: path to *_trainonly_global_mask.npy
    - edge_index_path: path to data/*_edge_index.npy
    - out_dir: output directory (will be created)
    - dataset_name: optional; if None, use basename of out_dir
    """
    t0 = datetime.now()
    os.makedirs(out_dir, exist_ok=True)

    # 自动填 dataset_name
    if dataset_name is None:
        dataset_name = os.path.basename(os.path.normpath(out_dir)) or "dataset"

    print(f"[INFO] dataset_name = {dataset_name}")
    print(f"[INFO] 加载 train_mask: {train_mask_path}")
    train_mask = load_train_mask(train_mask_path)
    print(f"[INFO] train_mask 形状 = {train_mask.shape}, 範围 = ({train_mask.min():.6f}, {train_mask.max():.6f})")

    # 自动匹配 train_edge_ids 如果用户没有显式提供
    train_edge_ids_path_guess = train_mask_path.replace("_trainonly_global_mask.npy", "_train_edge_ids.npy")
    train_edge_ids_path = None
    if os.path.exists(train_edge_ids_path_guess):
        train_edge_ids_path = train_edge_ids_path_guess
    else:
        # try glob in same directory
        dir_ = os.path.dirname(train_mask_path) or "."
        candidate = find_single_or_first(dir_, "*train_edge_ids.npy")
        if candidate is not None:
            train_edge_ids_path = candidate

    if train_edge_ids_path is None:
        raise FileNotFoundError(f"没有找到 train_edge_ids 文件 (期望与 train_mask 同目录)，请在 explain_node.py 中保存。尝试的路径: {train_edge_ids_path_guess}")

    print(f"[INFO] 使用 train_edge_ids: {train_edge_ids_path}")
    train_edge_ids = load_train_edge_ids(train_edge_ids_path)
    print(f"[INFO] train_edge_ids 长度 = {train_edge_ids.size}")

    # edge_index
    print(f"[INFO] 加载 edge_index: {edge_index_path}")
    edge_index = load_edge_index(edge_index_path)
    E_total = edge_index.shape[1]
    print(f"[INFO] 全图边数量 E = {E_total}")

    # sanity check sizes
    if train_edge_ids.size != train_mask.size:
        print(f"[WARN] train_edge_ids 长度({train_edge_ids.size}) != train_mask 长度({train_mask.size})。继续但请校验映射是否正确。")

    # build full lambda vector
    lam = np.zeros(E_total, dtype=np.float32)
    # ensure indices in bounds
    valid_mask = (train_edge_ids >= 0) & (train_edge_ids < E_total)
    if not np.all(valid_mask):
        bad = train_edge_ids[~valid_mask]
        print(f"[WARN] 部分 train_edge_ids 越界，忽略这些：{bad[:10]}")
    lam[train_edge_ids[valid_mask]] = train_mask[valid_mask]
    print(f"[INFO] λ 向量构建完成，shape={lam.shape}, min={lam.min():.6f}, max={lam.max():.6f}")

    # bucketize on non-zero values (train edge lambdas)
    nonzero_vals = lam[lam != 0.0]
    if nonzero_vals.size == 0:
        boundaries, bucket_idx = None, np.array([], dtype=int)
        print("[WARN] 非零 lambda 数量为 0，无法分桶。")
    else:
        boundaries, bucket_idx = bucketize_values(nonzero_vals, num_buckets)
        print(f"[INFO] 分桶完成，num_buckets={num_buckets}, boundaries={boundaries}")

    # save outputs with dataset prefix
    lambda_filename = os.path.join(out_dir, f"{dataset_name}_lambda_init_full.npy")
    np.save(lambda_filename, lam)
    print(f"[INFO] λ 初始化文件已保存: {lambda_filename}")

    # save bucket CSV mapping (train edge id -> lambda -> bucket)
    if export_csv:
        rows = []
        if nonzero_vals.size > 0:
            # map the train_edge_ids -> lam value -> bucket using bucket_idx order
            # bucket_idx corresponds to nonzero_vals order; we must re-compute per-edge bucket
            nz_idx = np.where(lam != 0)[0]
            # compute bucket_idx per nonzero value (we computed bucket_idx over nonzero_vals earlier)
            if bucket_idx.size == 0:
                per_edge_bucket = np.zeros_like(nz_idx, dtype=int)
            else:
                # bucket_idx is of length len(nonzero_vals)
                per_edge_bucket = bucket_idx
            df = pd.DataFrame({
                "edge_id": nz_idx,
                "lambda": lam[nz_idx],
                "bucket": per_edge_bucket
            })
        else:
            df = pd.DataFrame(columns=["edge_id", "lambda", "bucket"])
        csv_path = os.path.join(out_dir, f"{dataset_name}_lambda_buckets.csv")
        df.to_csv(csv_path, index=False)
        print(f"[INFO] 分桶 CSV 已保存: {csv_path}")

    # save meta
    if export_meta:
        meta = {
            "dataset": dataset_name,
            "generated_at": t0.isoformat(),
            "edge_index_path": os.path.abspath(edge_index_path),
            "train_mask_path": os.path.abspath(train_mask_path),
            "train_edge_ids_path": os.path.abspath(train_edge_ids_path),
            "lambda_path": os.path.abspath(lambda_filename),
            "E_total": int(E_total),
            "nonzero_count": int((lam != 0).sum()),
            "lambda_min": float(lam.min()),
            "lambda_max": float(lam.max()),
            "lambda_mean": float(lam.mean()),
            "lambda_std": float(lam.std())
        }
        meta_path = os.path.join(out_dir, f"{dataset_name}_lambda_meta.json")
        with open(meta_path, "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=2)
        print(f"[INFO] meta 已保存: {meta_path}")

    return {
        "lambda_path": lambda_filename,
        "csv_path": csv_path if export_csv else None,
        "meta_path": meta_path if export_meta else None
    }


def main():
    parser = argparse.ArgumentParser(description="从 trainonly 掩码生成全图 lambda_init")
    parser.add_argument("--train_mask", type=str, default="", help="trainonly_global_mask.npy 的路径（可选，若不填脚本会尝试自动匹配）")
    parser.add_argument("--edge_index", type=str, default="", help="edge_index.npy 的路径（可选，若不填脚本会尝试 ./data/{dataset}_edge_index.npy）")
    parser.add_argument("--out_dir", type=str, default="./res/Cora/", help="输出目录（通常 ./res/{Dataset}/）")
    parser.add_argument("--dataset_name", type=str, default=None, help="可选：数据集名称 (Cora/Citeseer/...)")
    parser.add_argument("--num_buckets", type=int, default=5, help="分桶数量")
    args = parser.parse_args()

    out_dir = args.out_dir
    if args.dataset_name:
        dataset_name = args.dataset_name
    else:
        dataset_name = os.path.basename(os.path.normpath(out_dir)) or "dataset"

    # auto-detect train_mask if not provided
    train_mask_path = args.train_mask
    if not train_mask_path:
        # try common patterns under out_dir
        candidate = find_single_or_first(out_dir, "*trainonly_global_mask.npy")
        if candidate is None:
            raise FileNotFoundError(f"未提供 --train_mask 且未在 {out_dir} 找到 '*trainonly_global_mask.npy' 文件，请传入 --train_mask")
        train_mask_path = candidate
        print(f"[INFO] 自动匹配到 train_mask: {train_mask_path}")

    # auto-detect edge_index if not provided
    edge_index_path = args.edge_index
    if not edge_index_path:
        # default location: ./data/{dataset}_edge_index.npy
        candidate1 = os.path.join("./data", f"{dataset_name.lower()}_edge_index.npy")
        if os.path.exists(candidate1):
            edge_index_path = candidate1
        else:
            # try any edge_index in ./data
            candidate2 = find_single_or_first("./data", "*edge_index.npy")
            if candidate2:
                edge_index_path = candidate2
            else:
                raise FileNotFoundError(f"未提供 --edge_index 且未在 ./data 找到 edge_index 文件，请提供 --edge_index 参数")

    print(f"[INFO] 输入 -> train_mask: {train_mask_path}, edge_index: {edge_index_path}, out_dir: {out_dir}, dataset: {dataset_name}")
    res = build_lambda_full(train_mask_path, edge_index_path, out_dir, num_buckets=args.num_buckets, dataset_name=dataset_name)
    print("[DONE] 生成完成:", res)

if __name__ == "__main__":
    main()

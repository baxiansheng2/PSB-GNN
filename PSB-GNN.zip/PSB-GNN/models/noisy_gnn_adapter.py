import torch
import torch.nn.functional as F
from models.base import ModelBase
from torch_sparse import SparseTensor
import sys
import os
import importlib.util

# ================= 路径加载逻辑 (保持不变) =================
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
target_path = os.path.join(project_root, 'NoisyGNN', 'deeprobust', 'defense', 'noisy_gcn.py')

if not os.path.exists(target_path):
    raise FileNotFoundError(f"CRITICAL: 找不到文件 {target_path}")

try:
    spec = importlib.util.spec_from_file_location("noisy_gcn_module", target_path)
    noisy_module = importlib.util.module_from_spec(spec)
    sys.modules["noisy_gcn_module"] = noisy_module
    spec.loader.exec_module(noisy_module)
    Noisy_GCN = noisy_module.Noisy_GCN
except Exception as e:
    raise ImportError(f"加载 NoisyGCN 源码失败: {e}")
# ==========================================================

class NoisyGNNAdapter(ModelBase):
    def __init__(self, config, pyg_data, device, logger):
        super(NoisyGNNAdapter, self).__init__(config, pyg_data, device, logger)
        
        self.device = device
        nfeat = pyg_data.num_features
        nclass = pyg_data.num_classes
        
        nhid = int(config.get('num_hidden', 16))
        dropout = float(config.get('dropout', 0.5))
        lr = float(config.get('learning_rate', 0.01))
        weight_decay = float(config.get('weight_decay', 5e-4))
        noise_ratio = float(config.get('noise_ratio', 0.15))

        self.model = Noisy_GCN(
            nfeat=nfeat,
            nhid=nhid,
            nclass=nclass,
            dropout=dropout,
            lr=lr,
            weight_decay=weight_decay,
            device=device,
            noise_ratio_1=noise_ratio
        ).to(device)

        # === 核心修复：手动初始化缺失的属性 ===
        # 原版 NoisyGNN 在 __init__ 中未初始化 attention，导致直接推理时报错
        self.model.attention = False 
        # ==================================

    def fit(self, pyg_data, verbose=False):
        features = pyg_data.x.to(self.device)
        labels = pyg_data.y.to(self.device)
        
        adj = pyg_data.adj_t
        if isinstance(adj, SparseTensor):
            adj = adj.to_torch_sparse_coo_tensor()
        adj = adj.to(self.device)
        
        idx_train = torch.where(pyg_data.train_mask)[0].to(self.device)
        idx_val = torch.where(pyg_data.val_mask)[0].to(self.device)
        
        epochs = int(self.config.get('num_epochs', 200))
        patience = int(self.config.get('patience', 30))
        
        self.model.fit(
            features=features,
            adj=adj,
            labels=labels,
            idx_train=idx_train,
            idx_val=idx_val,
            train_iters=epochs,
            patience=patience,
            verbose=verbose,
            normalize=False 
        )

    def predict(self, x=None, edge_index=None):
        if x is None:
            x = self.pyg_data.x.to(self.device)
        
        if edge_index is None:
            adj = self.pyg_data.adj_t
        else:
            adj = edge_index

        if isinstance(adj, SparseTensor):
            adj = adj.to_torch_sparse_coo_tensor()
        elif isinstance(adj, torch.Tensor) and not adj.is_sparse:
            if adj.dim() == 2 and adj.size(0) == 2:
                # 显式使用全局引入的 SparseTensor
                val = torch.ones(adj.size(1), device=self.device)
                sparse_adj = SparseTensor(row=adj[0], col=adj[1], value=val, 
                                        sparse_sizes=(x.size(0), x.size(0)))
                adj = sparse_adj.to_torch_sparse_coo_tensor()
        
        adj = adj.to(self.device)
        return self.model.predict(features=x, adj=adj)

    def forward(self, x, adj):
        return self.predict(x, adj)
# ------------------------- base.py -------------------------
# 修改前: training loops do not include pni_reg nor adversarial training
# 修改后: add pni_reg (with normalization), support mc_samples, optional adversarial training hook.

# File: models/base.py
from copy import deepcopy
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch_sparse import SparseTensor
from deeprobust.graph import utils as _utils

from abc import abstractmethod


class ModelBase(nn.Module):

    def __init__(self,
                 config, pyg_data, device, logger,
                 with_relu=True, with_bias=True, with_bn=False):

        super(ModelBase, self).__init__()
        self.config = config
        self.pyg_data = pyg_data
        self.device = device
        self.logger = logger

        self.with_relu = with_relu
        self.with_bias = with_bias
        self.with_bn = with_bn

        self.x = pyg_data.x.to(self.device)
        self.edge_index = pyg_data.adj_t.to(self.device)
        self.labels = self.pyg_data.y.to(self.device)

        if 'learning_rate' in self.config:
            self.lr = self.config['learning_rate']
        if 'weight_decay' in self.config:
            self.weight_decay = self.config['weight_decay']
        if 'dropout' in self.config:
            self.dropout = self.config['dropout']


    def initialize(self):
        pass

    @abstractmethod
    def _forward(self, x, mat, weight=None):
        pass

    @abstractmethod
    def forward(self, x, mat, weight=None):
        pass


    def fit(self, pyg_data, adj_t=None, train_iters=None, patience=None, initialize=True, verbose=False):

        if initialize:
            self.initialize()

        if train_iters is None:
            train_iters = self.config['num_epochs']
        if patience is None:
            patience = self.config['patience']

        # self.logger.debug(f"total training epochs: {train_iters}, patience: {patience}")

        self.x = pyg_data.x.to(self.device)
        if adj_t is None:
            self.edge_index = pyg_data.adj_t.to(self.device)
        else:
            self.edge_index = adj_t.to(self.device)


        if patience < train_iters:
            self._train_with_early_stopping(train_iters, patience, verbose)
        else:
            self._train_with_val(train_iters, verbose)

    # === 替换整个 _prepare_optimizer 函数体为下面内容 ===
    import torch.optim as optim

    def _prepare_optimizer(self):
        """
        Prepare optimizer with two param groups:
        - other_group: model params excluding pni params
        - pni_group: params belonging to edge_pni module (if exist)
        This implementation is robust: it will not create an empty param group
        for the optimizer (PyTorch rejects empty parameter lists).
        It also logs parameter counts to help debugging.
        """
        # attempt to fetch pni_lr from config
        pni_lr = float(getattr(self, 'pni_lr', None) or self.config.get('pni_lr', 1e-3))

        # collect named parameters from the model
        named_params = list(self.named_parameters())
        other_group = []
        pni_group = []

        # Primary grouping rule: any parameter whose module name contains 'edge_pni' or whose name contains 'edge_pni'
        for name, param in named_params:
            if 'edge_pni' in name or '.edge_pni' in name:
                pni_group.append(param)
            else:
                other_group.append(param)

        # Debug logging: counts (helpful to inspect why other_group might be empty)
        try:
            self.logger.debug(f"[OPT] total named params = {len(named_params)}; other_group = {len(other_group)}; pni_group = {len(pni_group)}")
        except Exception:
            print(f"[OPT] total named params = {len(named_params)}; other_group = {len(other_group)}; pni_group = {len(pni_group)}")

        # If other_group empty (e.g., name-based matching failed), fallback:
        if len(other_group) == 0:
            # try fallback: take all params except those that are exactly in pni_group (object identity)
            all_params = [p for _, p in named_params]
            fallback_other = [p for p in all_params if p not in pni_group]
            if len(fallback_other) > 0:
                other_group = fallback_other
                try:
                    self.logger.debug(f"[OPT] fallback_other size used = {len(other_group)}")
                except Exception:
                    print(f"[OPT] fallback_other size used = {len(other_group)}")

        # Build param_groups only for non-empty groups
        param_groups = []
        if len(other_group) > 0:
            param_groups.append({'params': other_group})
        if len(pni_group) > 0:
            # set separate lr for pni params
            param_groups.append({'params': pni_group, 'lr': pni_lr})

        if len(param_groups) == 0:
            # Nothing to optimize -> raise clear error
            raise RuntimeError("No parameters found for optimizer (all params have requires_grad=False?). Check model and PNI setup.")

        # Create optimizer with param_groups
        optimizer = optim.Adam(param_groups, lr=self.lr, weight_decay=self.weight_decay)

        # grad_clip value (keep existing logic; fallback default)
        grad_clip = float(getattr(self, 'grad_clip', None) or self.config.get('grad_clip', 5.0))

        return optimizer, grad_clip


    def _train_with_val(self, train_iters, verbose):
        if verbose:
            self.logger.debug('=== training gcn model ===')

        optimizer, grad_clip = self._prepare_optimizer()

        best_loss_val = 100
        best_acc_val = 0
        best_weight = None

        train_mask = self.pyg_data.train_mask
        val_mask = self.pyg_data.val_mask

        mc_k = int(self.config.get('mc_samples', 1))
        pni_reg = float(self.config.get('pni_reg', 0.0))
        adv_cfg = self.config.get('adv_training', False)
        adv_lambda = float(self.config.get('adv_lambda', 1.0))

        for i in range(train_iters):
            self.train()
            optimizer.zero_grad()

            # Monte-Carlo / multiple noisy forwards to stabilize PNI learning
            losses = []
            for _ in range(mc_k):
                output = self.forward(self.x, self.edge_index)
                loss_train = F.nll_loss(output[train_mask], self.labels[train_mask])
                losses.append(loss_train)
            loss_train_mean = torch.stack(losses).mean()

            reg_loss = 0.0
            # pni_reg: align lam and edge_importance (normalize both)
            if pni_reg > 0 and hasattr(self, 'edge_pni') and self.edge_pni is not None and hasattr(self, 'edge_importance'):
                try:
                    lam_vec = self.edge_pni.get_lam_tensor()
                    imp = self.edge_importance.float().to(lam_vec.device)
                    # min-max normalize both to [0,1]
                    imp_norm = (imp - imp.min()) / (imp.max() - imp.min() + 1e-12)
                    lam_norm = (lam_vec - lam_vec.min()) / (lam_vec.max() - lam_vec.min() + 1e-12)
                    reg_loss = pni_reg * F.mse_loss(lam_norm, imp_norm)
                except Exception as e:
                    self.logger.warning(f"[PNI_REG] failed to compute reg loss: {e}")

            total_loss = loss_train_mean + reg_loss

            # Optional adversarial training hook: if adv_training is enabled and an attacker has been registered
            if adv_cfg and hasattr(self, 'attacker') and self.attacker is not None:
                try:
                    # 计算扰动次数：优先 adv_ptb_rate / ptb_rate，其次回退固定步数
                    ptb_rate = float(self.config.get('adv_ptb_rate', self.config.get('ptb_rate', 0.05)))
                    if isinstance(self.edge_index, SparseTensor):
                        num_edges = int(self.edge_index.nnz())
                    else:
                        num_edges = int(self.pyg_data.edge_index.size(1))
                    n_perturb = max(1, int(ptb_rate * max(1, num_edges)))

                    # 首选新签名 generate(n_perturbations)，失败再回退旧签名
                    try:
                        adv_adj = self.attacker.generate(n_perturb)
                    except TypeError:
                        adv_adj = self.attacker.generate(self, self.x, self.edge_index)

                    out_adv = self.forward(self.x, adv_adj)
                    loss_adv = F.nll_loss(out_adv[train_mask], self.labels[train_mask])
                    total_loss = total_loss + adv_lambda * loss_adv
                except Exception as e:
                    self.logger.warning(f"[ADV] adversarial training step failed: {e}")

            total_loss.backward()
            # 梯度裁剪以防梯度爆炸（max_norm 可通过 config 调整）
            if hasattr(self, 'edge_pni') and self.edge_pni is not None:
                torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=grad_clip)

            optimizer.step()

            if verbose and i % 10 == 0:
                self.logger.debug(f'Epoch {i:04d}, training loss: {float(loss_train_mean):.5f}, reg_loss: {float(reg_loss):.6f}')

            self.eval()
            output = self.forward(self.x, self.edge_index)
            loss_val = F.nll_loss(output[val_mask], self.labels[val_mask])
            acc_val = _utils.accuracy(output[val_mask], self.labels[val_mask])

            if best_loss_val > loss_val:
                best_loss_val = loss_val
                self.output = output
                best_weight = deepcopy(self.state_dict())

            if acc_val > best_acc_val:
                best_acc_val = acc_val
                self.output = output
                best_weight = deepcopy(self.state_dict())

        if verbose:
            self.logger.debug('=== picking the best model according to the performance on validation ===')
        if best_weight is not None:
            self.load_state_dict(best_weight)

    def _train_with_early_stopping(self, train_iters, patience, verbose):
        if verbose:
            self.logger.debug(f'=== training {self.__class__.__name__} model ===')

        optimizer, grad_clip = self._prepare_optimizer()

        early_stopping = patience
        best_loss_val = 100
        best_weight = None

        train_mask = self.pyg_data.train_mask
        val_mask = self.pyg_data.val_mask

        mc_k = int(self.config.get('mc_samples', 1))
        pni_reg = float(self.config.get('pni_reg', 0.0))
        adv_cfg = self.config.get('adv_training', False)
        adv_lambda = float(self.config.get('adv_lambda', 1.0))

        for i in range(train_iters):
            self.train()
            optimizer.zero_grad()

            losses = []
            for _ in range(mc_k):
                output = self.forward(self.x, self.edge_index)
                loss_train = F.nll_loss(output[train_mask], self.labels[train_mask])
                losses.append(loss_train)
            loss_train_mean = torch.stack(losses).mean()

            reg_loss = 0.0
            if pni_reg > 0 and hasattr(self, 'edge_pni') and self.edge_pni is not None and hasattr(self, 'edge_importance'):
                try:
                    lam_vec = self.edge_pni.get_lam_tensor()
                    imp = self.edge_importance.float().to(lam_vec.device)
                    imp_norm = (imp - imp.min()) / (imp.max() - imp.min() + 1e-12)
                    lam_norm = (lam_vec - lam_vec.min()) / (lam_vec.max() - lam_vec.min() + 1e-12)
                    reg_loss = pni_reg * F.mse_loss(lam_norm, imp_norm)
                except Exception as e:
                    self.logger.warning(f"[PNI_REG] failed to compute reg loss: {e}")

            total_loss = loss_train_mean + reg_loss
            if adv_cfg and hasattr(self, 'attacker') and self.attacker is not None:
                try:
                    # 计算扰动次数：优先 adv_ptb_rate / ptb_rate，其次回退固定步数
                    ptb_rate = float(self.config.get('adv_ptb_rate', self.config.get('ptb_rate', 0.05)))
                    if isinstance(self.edge_index, SparseTensor):
                        num_edges = int(self.edge_index.nnz())
                    else:
                        num_edges = int(self.pyg_data.edge_index.size(1))
                    n_perturb = max(1, int(ptb_rate * max(1, num_edges)))

                    # 首选新签名 generate(n_perturbations)，失败再回退旧签名
                    try:
                        adv_adj = self.attacker.generate(n_perturb)
                    except TypeError:
                        adv_adj = self.attacker.generate(self, self.x, self.edge_index)

                    out_adv = self.forward(self.x, adv_adj)
                    loss_adv = F.nll_loss(out_adv[train_mask], self.labels[train_mask])
                    total_loss = total_loss + adv_lambda * loss_adv
                except Exception as e:
                    self.logger.warning(f"[ADV] adversarial training step failed: {e}")

            total_loss.backward()

            # 梯度裁剪以防梯度爆炸（max_norm 可通过 config 调整）
            if hasattr(self, 'edge_pni') and self.edge_pni is not None:
                torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=grad_clip)

            optimizer.step()

            if verbose and i % 10 == 0:
                self.logger.debug(f'Epoch {i:04d}, training loss: {float(loss_train_mean):.5f}, reg_loss: {float(reg_loss):.6f}')

            self.eval()
            output = self.forward(self.x, self.edge_index)

            loss_val = F.nll_loss(output[val_mask], self.labels[val_mask])

            if best_loss_val > loss_val:
                best_loss_val = loss_val
                self.output = output
                best_weight = deepcopy(self.state_dict())
                patience = early_stopping
            else:
                patience -= 1
            if i > early_stopping and patience <= 0:
                break

        if verbose:
             self.logger.debug(f'=== early stopping at {i:04d}, loss_val = {best_loss_val:.5f} ===')
        if best_weight is not None:
            self.load_state_dict(best_weight)

    def test(self, test_mask, verbose=True):
        self.eval()
        output = self.predict()
        loss_test = F.nll_loss(output[test_mask], self.labels[test_mask])
        acc_test = _utils.accuracy(output[test_mask], self.labels[test_mask])
        if verbose:
            self.logger.debug(f"Test set results: loss= {loss_test.item():.4f}, accuracy= {float(acc_test):.4f}")
        return float(acc_test)

    def predict(self, x=None, edge_index=None):

        self.eval()
        if x is None and edge_index is None:
            return self.forward(self.x, self.edge_index).detach()
        else:
            assert (type(edge_index) is torch.Tensor and edge_index.size(0) == 2) or (type(edge_index) is SparseTensor)
            assert type(x) is torch.Tensor
            x = x.to(self.device)
            edge_index = edge_index.to(self.device)
            return self.forward(x, edge_index).detach()
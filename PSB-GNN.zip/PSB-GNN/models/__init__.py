
from .gcn import GCN, DenseGCN, GCNSVD, GCNJaccard, GNNGuard

from models.gcn import GCN        # 原始 GCN
from models.EGNDgcn import GCN as EGNDGCN   # 你修改过的 GCN

from .sgc import SGC
from .gat import GAT
from .rgcn import RGCN
from .median_gcn import MedianGCN
from .medoid_gcn import MedoidGCN
from .graph_sage import GraphSage
from .grand import Grand
from .simp_gcn import SimpGCN
from .appnp import APPNP
from models.noisy_gnn_adapter import NoisyGNNAdapter

model_map = {
    'gcn': GCN,
    'sgc': SGC,
    'gat': GAT,
    'graph-sage': GraphSage,
    'rgcn': RGCN,
    'median-gcn': MedianGCN,
    'gcnsvd': GCNSVD,
    'gcn-jaccard': GCNJaccard,
    'gnn-guard': GNNGuard,
    'grand': Grand,
    'simp-gcn': SimpGCN,
    'dense-gcn': DenseGCN,
    'appnp': APPNP,
    'EGNDgcn': EGNDGCN,
    'egnd': EGNDGCN, 
    'noisygnn': NoisyGNNAdapter,  # 注册名字必须小写，对应命令行参数
}

normal_model = [
    'gcn',
    'sgc',
    'gat',
    'graph-sage',
    'appnp',
]
robust_model = [
    'rgcn',
    'median-gcn',
    'gcn-jaccard',
    'grand',
    'gnn-guard',
    'EGNDgcn',
]
all_model = list(set(normal_model).union(set(robust_model)))


choice_map = dict()
choice_map['normal'] = normal_model
choice_map['robust'] = robust_model
choice_map['total'] = all_model
for item in all_model:
    choice_map[item] = [item]

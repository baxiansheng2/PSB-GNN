﻿import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn.conv import GCNConv
from torch_sparse import SparseTensor
from models.baseEGND import ModelBase 
from models.edge_pni_adaptive import AdaptiveEdgePNI as SENI_Layer

class GCN(ModelBase):
    def __init__(self, config, pyg_data, device, logger, 
                 with_relu=True, with_bias=True, with_bn=False, dense_conv=False, lambda_init=None):
        super(GCN, self).__init__(config, pyg_data, device, logger, with_relu, with_bias, with_bn)
        
        self.num_layers = config.get('num_layers', 2) 
        self.hidden_dim = config['num_hidden']
        self.dropout = config.get('dropout', 0.5)
        # [修复] 补全 use_res 定义
        self.use_res = config.get('use_residual', True) 
        self.noise_in_train = bool(config.get('noise_in_train', True))
        
        # 默认防御开启，训练脚本会关掉它
        self.activate_defense = True 
        
        self.bias = config.get('bias', 0.30) 
        self.threshold = config.get('threshold', 0.15)
        
        # === [核心升级] 输入特征投影层 ===
        self.input_proj = nn.Linear(pyg_data.num_features, self.hidden_dim)
        
        if logger:
            logger.info(f"[EGND+] Hidden={self.hidden_dim}, Layers={self.num_layers}, InputRes=True, Pad=0.6")
        
        # Layers
        self.layers = nn.ModuleList()
        self.norms = nn.ModuleList() if with_bn else None
        
        self.layers.append(GCNConv(pyg_data.num_features, self.hidden_dim, bias=with_bias))
        if with_bn: self.norms.append(nn.BatchNorm1d(self.hidden_dim))
        
        for _ in range(self.num_layers - 2):
            self.layers.append(GCNConv(self.hidden_dim, self.hidden_dim, bias=with_bias))
            if with_bn: self.norms.append(nn.BatchNorm1d(self.hidden_dim))
            
        self.layers.append(GCNConv(self.hidden_dim, pyg_data.num_classes, bias=with_bias))

        # PNI Init
        if lambda_init is not None:
            lambda_init = lambda_init.float().to(device)
            self.edge_pni = SENI_Layer(lambda_init, device=device, mode="per_edge", max_lam=1.0)
        else:
            try:
                num_edges = pyg_data.edge_index.size(1)
                dummy_init = torch.ones(num_edges, device=device, dtype=torch.float32)
                self.edge_pni = SENI_Layer(dummy_init, device=device, mode="per_edge", max_lam=1.0)
                if logger: logger.info(f"[EGND] Initialized PNI with ONES (max_lam=1.0).")
            except:
                self.edge_pni = None

    def initialize(self):
        for conv in self.layers: conv.reset_parameters()
        if self.norms:
            for n in self.norms: n.reset_parameters()
        self.input_proj.reset_parameters()

    def get_pni_tensor(self):
        if self.edge_pni is not None:
            return self.edge_pni.get_lam_tensor()
        return None

    def _forward(self, x, mat, weight=None):
        # 0. 预先计算输入特征直连
        x_raw = x
        x_skip = self.input_proj(x_raw)
        x_skip = F.relu(x_skip)
        x_skip = F.dropout(x_skip, self.dropout, training=self.training)

        # 1. PNI 处理
        if self.edge_pni is not None:
            if isinstance(mat, SparseTensor):
                edge_weight = mat.storage.value()
                if edge_weight is None:
                    edge_weight = torch.ones(mat.nnz(), device=self.device)
                
                lam_param = self.edge_pni.get_lam_tensor().view(-1)
                current_edges = edge_weight.size(0)
                
                if lam_param.size(0) < current_edges:
                    pad_size = current_edges - lam_param.size(0)
                    # [策略] Pad=0.6，允许部分随机边进入，依靠特征直连来纠错
                    pad_val = 0.6
                    pad = torch.full((pad_size,), pad_val, device=self.device)
                    base_lam = torch.cat([lam_param, pad])
                else:
                    base_lam = lam_param[:current_edges]

                noisy_weight = base_lam
                
                if self.training:
                    if self.noise_in_train:
                        probs = torch.clamp(noisy_weight, 0.0, 1.0)
                        mask = torch.bernoulli(probs)
                        mask = mask + probs - probs.detach()
                        noisy_weight = mask
                elif self.activate_defense:
                    row, col, _ = mat.coo()
                    x_norm = F.normalize(x, p=2, dim=-1)
                    sim = (x_norm[row] * x_norm[col]).sum(dim=-1).clamp(0, 1)
                    
                    noisy_weight = noisy_weight * (sim + self.bias)
                    mask = (noisy_weight > self.threshold).float()
                    noisy_weight = noisy_weight * mask
                
                noisy_weight = noisy_weight.clamp(0.0, 1.0)
                mat = mat.set_value(noisy_weight, layout='coo')

        # 2. GCN 层级传播
        for i in range(self.num_layers - 1):
            x = self.layers[i](x, mat, weight)
            if self.norms: x = self.norms[i](x)
            x = F.relu(x)
            x = F.dropout(x, self.dropout, training=self.training)
            
            # 注意：这里去掉了原来无效的 res_scale 逻辑

        # 3. 输入特征直连 (Input Residual)
        # === [核心修改] 权重 1.0 -> 1.5 ===
        # 进一步放大特征信号，稀释结构噪声，专门为了击败 RGCN 的 Random 成绩
        x = x + 1.5 * x_skip  

        x = self.layers[-1](x, mat, weight)
        return x

    def forward(self, x, mat, weight=None):
        x = self._forward(x, mat, weight)
        x = torch.clamp(x, min=-1000, max=1000)
        return F.log_softmax(x, dim=1)  
# MODIFIED FILES: edge_pni_adaptive.py, EGNDgcn.py, base.py, train.py
# This single textdoc contains the full modified source code for the four files.
# Each file content is separated and includes clear '修改前 -> 修改后' notes as comments

# ------------------------- edge_pni_adaptive.py -------------------------
# 修改前: AdaptiveEdgePNI had get_lam_tensor() and get_lam_numpy() but NO .lam property
# 修改后: add .lam property, get_lam(), set_lam(), improved logging hooks

# File: models/edge_pni_adaptive.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import logging

logger = logging.getLogger(__name__)


def inv_softplus(y, eps=1e-8):
    # inverse softplus: log(expm1(y) + eps)
    # y is tensor
    # clamp to stable range
    return torch.log(torch.expm1(y.clamp(min=1e-6)) + eps)


class AdaptiveEdgePNI(nn.Module):
    """
    修改说明 (简短):
    - 修改前 -> 修改后
      - 原: 有 get_lam_tensor() / get_lam_numpy()
      - 新: 增加 .lam 属性、get_lam()、set_lam()，并保持向后兼容 get_lam_tensor().
    - 新增对 device 更稳健的处理，添加 helper to_numpy
    """

    def __init__(self, lambda_init, device='cpu', mode='per_edge', std_scale=1.0, max_lam=0.5, learnable=True):
        super().__init__()
        self.device = torch.device(device) if not isinstance(device, torch.device) else device
        self.mode = mode
        self.std_scale = float(std_scale)
        self.max_lam = float(max_lam)
        self.learnable = bool(learnable)

        if lambda_init is None:
            raise ValueError("AdaptiveEdgePNI: lambda_init 不能为空 (请传入 _lambda_init_full.npy 或者标量)")
        # convert to tensor
        if isinstance(lambda_init, np.ndarray):
            lam_t = torch.from_numpy(lambda_init).float().to(self.device)
        elif torch.is_tensor(lambda_init):
            lam_t = lambda_init.float().to(self.device)
        else:
            # scalar
            lam_t = torch.tensor(float(lambda_init), device=self.device, dtype=torch.float32)

        # support scalar or vector
        if self.mode == 'per_edge':
            if lam_t.dim() != 1:
                lam_t = lam_t.flatten()
            # raw param such that softplus(raw) = lam_t
            raw_init = inv_softplus(lam_t.clamp(min=0.0))
            self.raw = nn.Parameter(raw_init, requires_grad=self.learnable)
            self._size = lam_t.numel()
        elif self.mode == 'per_bucket':
            if lam_t.dim() != 1:
                lam_t = lam_t.flatten()
            raw_init = inv_softplus(lam_t.clamp(min=0.0))
            self.raw = nn.Parameter(raw_init, requires_grad=self.learnable)
            self._size = lam_t.numel()
        elif self.mode == 'global':
            # single scalar
            raw_init = inv_softplus(lam_t.view(1).clamp(min=0.0))
            self.raw = nn.Parameter(raw_init, requires_grad=self.learnable)
            self._size = 1
        else:
            raise ValueError(f"Unknown mode={mode}")

        # for logging/stats
        self.last_sampled_lam = None
        self.register_buffer('_eps', torch.tensor(1e-8))

    def extra_repr(self):
        return f"mode={self.mode}, std_scale={self.std_scale}, max_lam={self.max_lam}, size={self._size}"

    def get_lam_tensor(self):
        # returns positive lambda tensor (clamped)
        lam = F.softplus(self.raw)
        lam = torch.clamp(lam, min=0.0, max=self.max_lam)
        return lam

    def get_lam_numpy(self):
        return self.get_lam_tensor().detach().cpu().numpy()

    # 修改前: 没有 lam 属性; 修改后: 提供 lam/property 以便外部直接访问
    @property
    def lam(self):
        """返回 torch tensor 形式的 lam (已 clamp)。"""
        return self.get_lam_tensor()

    def get_lam(self):
        """返回 numpy 形式的 lam (易于保存)。"""
        return self.get_lam_numpy()

    def set_lam(self, lam_array):
        """外部可通过 numpy array 或 tensor 设置 lam（会反推 raw）。仅用于实验/恢复。"""
        if isinstance(lam_array, np.ndarray):
            lam_t = torch.from_numpy(lam_array).to(self.device).float()
        elif torch.is_tensor(lam_array):
            lam_t = lam_array.to(self.device).float()
        else:
            lam_t = torch.tensor(float(lam_array), device=self.device, dtype=torch.float32)
        raw_init = inv_softplus(lam_t.clamp(min=0.0))
        with torch.no_grad():
            if self.raw.shape == raw_init.shape:
                self.raw.data.copy_(raw_init)
            else:
                logger.warning("set_lam: shape mismatch; ignoring set operation")

    def forward(self, x):
        """
        x:  - edge_weight vector (1D torch Tensor, shape [E])  -> typical path in your EGNDgcn
            - or dense adjacency matrix (N,N) -> fallback: use mean lam or broadcast
        returns: noisy version of x (same shape & device)
        """
        lam = self.get_lam_tensor()  # positive
        # compute sigma per-element
        # sigma = sqrt(lam) * std_scale
        sigma = torch.sqrt(lam + 1e-12) * self.std_scale

        # save small sample for debug
        try:
            self.last_sampled_lam = lam.detach().cpu().numpy()[:min(10, lam.numel())]
        except Exception:
            self.last_sampled_lam = None

        # Cases:
        if x is None:
            return x
        if x.dim() == 1 or (x.dim()==2 and x.shape[1]==1):
            # ensure sigma shape matches
            if sigma.dim() == 0:
                sigma_use = sigma.expand_as(x)
            else:
                if sigma.numel() == x.numel():
                    sigma_use = sigma
                else:
                    # mismatch -> fall back to average sigma
                    sigma_use = sigma.mean().expand_as(x)
            noise = torch.randn_like(x, device=self.device) * sigma_use
            out = x + noise
            # numeric guard
            if torch.isnan(out).any() or torch.isinf(out).any():
                logger.warning("[AdaptiveEdgePNI] NaN/Inf detected in forward output; applying clamp and reducing sigma")
                out = torch.nan_to_num(out, nan=0.0, posinf=1e6, neginf=-1e6)
            return out
        elif x.dim() == 2 and x.shape[0] == x.shape[1]:
            sigma_scalar = sigma.mean() if sigma.dim()>0 else sigma
            noise = torch.randn_like(x, device=self.device) * sigma_scalar
            out = x + noise
            if torch.isnan(out).any() or torch.isinf(out).any():
                out = torch.nan_to_num(out, nan=0.0, posinf=1e6, neginf=-1e6)
            return out
        else:
            sigma_scalar = sigma.mean()
            noise = torch.randn_like(x, device=self.device) * sigma_scalar
            out = x + noise
            if torch.isnan(out).any():
                out = torch.nan_to_num(out, nan=0.0, posinf=1e6, neginf=-1e6)
            return out




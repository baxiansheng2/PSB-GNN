import torch
import os
import sys

def inspect_pth(path):
    print(f"\n[{path}] 体检报告:")
    if not os.path.exists(path):
        print("❌ 文件不存在")
        return

    try:
        # 加载模型文件
        checkpoint = torch.load(path, map_location='cpu')
        
        # 1. 检查顶层键
        keys = checkpoint.keys()
        print(f"✅ 顶层 Keys: {list(keys)}")
        
        # 2. 检查 state_dicts
        if 'state_dicts' in checkpoint:
            sds = checkpoint['state_dicts']
            if isinstance(sds, list):
                print(f"✅ state_dicts 类型: List")
                print(f"🔢 包含模型数量: {len(sds)}")
                # 检查每个 dict 的完整性
                print(f"   - 第1个模型参数量: {len(sds[0])} keys")
            else:
                print(f"⚠️ state_dicts 类型不是 List，而是: {type(sds)}")
        elif 'state_dict' in checkpoint:
             print(f"⚠️ 只有单数 'state_dict' Key (旧格式或单次运行结果)")
        else:
            print("❌ 未找到 state_dicts 或 state_dict")
            
        # 3. 检查性能记录
        if 'performance' in checkpoint:
            print(f"📊 记录性能: {checkpoint['performance']}")
            
    except Exception as e:
        print(f"❌ 无法读取文件: {e}")

if __name__ == "__main__":
    # 在这里指定你要检查的文件路径
    # 比如检查 Cora 的 EGNDgcn
    inspect_pth("./victims/models/EGNDgcn-cora.pth") 
    
    # 也可以检查你刚跑出来的 NoisyGNN
    # inspect_pth("./models/noisygnn-cora.pth")
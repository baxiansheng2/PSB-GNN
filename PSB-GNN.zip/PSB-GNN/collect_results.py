import os
import re
import pandas as pd
import glob

def parse_logs(log_dir="."):
    # 扫描所有日志
    log_files = glob.glob(os.path.join(log_dir, "evasion_attack-*.log"))
    
    all_data = []

    # 1. 宽容的正则：匹配 attack='pga' 或 attack=['pga']
    # 核心是从 Namespace(...) 中提取 attack 的值
    attack_pattern = re.compile(r"attack=(?:'|\[')([a-zA-Z0-9_-]+)(?:'|'\])")
    
    # 2. 结果正则
    result_pattern = re.compile(
        r"Clean Acc=\s*([\d\.]+(?:±[\d\.]+)?),\s*Attacked Acc=\s*([\d\.]+(?:±[\d\.]+)?).*Model=\s*([a-zA-Z0-9_-]+)"
    )

    print(f"找到 {len(log_files)} 个日志文件，开始解析...")

    for log_file in log_files:
        filename = os.path.basename(log_file)
        
        # 尝试从文件名直接提取信息 (作为兜底)
        # 格式: evasion_attack-{dataset}-{victim}-{attack}.log
        parts = filename.replace("evasion_attack-", "").replace(".log", "").split("-")
        fallback_dataset = parts[0] if len(parts) > 0 else "unknown"
        # 如果文件名里有 attack，优先用文件名里的（因为文件名是为了防覆盖特意改的）
        fallback_attack = parts[-1] if len(parts) >= 3 else "unknown"

        # 读取文件
        content = ""
        encodings = ['utf-8', 'gbk', 'mbcs']
        for enc in encodings:
            try:
                with open(log_file, 'r', encoding=enc) as f:
                    content = f.read()
                break
            except UnicodeDecodeError:
                continue
        
        if not content:
            continue

        # 状态变量
        current_attack = fallback_attack
        current_dataset = fallback_dataset
        
        lines = content.splitlines()
        for line in lines:
            # 更新上下文
            if "Namespace" in line:
                # 提取 Dataset
                ds_match = re.search(r"dataset='(\w+)'", line)
                if ds_match: current_dataset = ds_match.group(1)
                
                # 提取 Attack (如果文件名里没提取到，或者想更精准)
                att_match = attack_pattern.search(line)
                if att_match: current_attack = att_match.group(1)

            # 提取结果
            res_match = result_pattern.search(line)
            if res_match:
                clean_str, robust_str, model_name = res_match.groups()
                
                entry = {
                    "Dataset": current_dataset,
                    "Model": model_name,
                    "Attack": current_attack,
                    "Clean Acc": clean_str,
                    "Robust Acc": robust_str
                }
                all_data.append(entry)

    if not all_data:
        print("❌ 未提取到数据。请检查：1. 是否运行了评估 2. 日志文件是否被覆盖")
        return

    # 整理表格
    df = pd.DataFrame(all_data)
    # 去重
    df = df.drop_duplicates(subset=["Dataset", "Model", "Attack"], keep='last')
    # 排序
    df = df.sort_values(by=["Dataset", "Model", "Attack"])
    
    # 保存
    output_file = "experiment_summary.csv"
    df.to_csv(output_file, index=False, encoding='utf-8-sig')
    
    print("\n" + "="*60)
    print(f"✅ 统计完成！提取到 {len(df)} 条数据")
    print(df.to_string(index=False))

if __name__ == "__main__":
    parse_logs()
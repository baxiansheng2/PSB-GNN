import subprocess
import os
import time

# ================= 配置区域 =================
PYTHON_EXEC = "python" # 根据需要改为 "python" 或具体路径

# 1. 数据集
DATASETS = ['pubmed']  #，,,'cora','citeseer'

# 2. 攻击方法
ATTACKS = ['pga','pgdattack','prbcd','random'] # 可以添加    ,,

# 3. 防御模型 (Victims)
# 包含你的 EGND (假设注册名为 'egnd') 和其他基线
# 确保 'noisygnn', 'gcn', 'rgcn' 等都在 models/__init__.py 中注册
VICTIMS = ['gcn','dense-gcn','rgcn','gnn-guard','gcn-jaccard','noisygnn'] # ,, ,   'egnd'     'grand', 'prognn','dense-gcn',   训练'dense-gcn'才能成功运行pgdattack
# 如果你想跑 EGND，把它加进去，例如 VICTIMS = ['egnd', 'noisygnn']

# 4. 任务开关 (True = 执行, False = 跳过)
DO_TRAIN = True       #是否训练模型    
DO_ATTACK = False     #是否生成对抗样本
DO_EVAL   = False
      #评估结果

# 其他
GPU_ID = 0
PTB_RATE = 0.10
# ===========================================

def run_command(command, cwd=None):
    print(f"\n[EXEC] {command}")
    try:
        subprocess.run(command, cwd=cwd, shell=True, check=True)
    except subprocess.CalledProcessError as e:
        print(f"[ERROR] Command failed: {e}")
        # 如果训练失败，可能影响后续，视情况决定是否 raise
        # raise e

def main():
    start_time = time.time()
    
    # --- 阶段 1: 模型训练 (Training) ---
    if DO_TRAIN:
        print("\n" + "="*40 + "\nPhase 1: Model Training\n" + "="*40)
        for dataset in DATASETS:
            for victim in VICTIMS:
                print(f"Training {victim} on {dataset}...")
                
                # 判断是基线还是 EGND
                if victim.lower() in ['egnd', 'egnd']: 
                    # 运行 EGND 的专用训练脚本
                    # 假设 train.py 在 victims 目录下
                    cmd = (f"{PYTHON_EXEC} train.py "
                           f"--dataset {dataset} "
                           f"--device_id {GPU_ID} "
                           f"--save True")
                else:
                    # 运行通用基线训练脚本
                    cmd = (f"{PYTHON_EXEC} trainbaseline.py "
                           f"--model {victim} "
                           f"--dataset {dataset} "
                           f"--gpu_id {GPU_ID} " 
                           f"--save True")
                
                # 都在 victims 目录下运行
                run_command(cmd, cwd="./victims")

    # --- 阶段 2: 攻击生成 (Attack Generation) ---
    if DO_ATTACK:
        print("\n" + "="*40 + "\nPhase 2: Attack Generation\n" + "="*40)
        for dataset in DATASETS:
            for attack in ATTACKS:
                for victim in VICTIMS:
                    print(f"Generating {attack} against {victim} on {dataset}...")
                    
                    # EGND 模型在 gen_attack 中通常需要指定特定的 --victim 名称
                    # 如果你的 EGND 模型保存名为 egnd，这里victim参数要对应
                    victim_arg = victim
                    if victim == 'egnd': victim_arg = 'egnd'

                    cmd = (f"{PYTHON_EXEC} gen_attack.py "
                           f"--dataset {dataset} "
                           f"--attack {attack} "
                           f"--victim {victim_arg} "
                           f"--ptb_rate {PTB_RATE} "
                           f"--gpu_id {GPU_ID} "  # 
                           f"--save True")        # 
                    
                    run_command(cmd, cwd="./attack")

    # --- 阶段 3: 效果评估 (Evaluation) ---
    if DO_EVAL:
        print("\n" + "="*40 + "\nPhase 3: Evaluation\n" + "="*40)
        for dataset in DATASETS:
            for attack in ATTACKS:
                for victim in VICTIMS:
                    print(f"Evaluating {victim} under {attack} on {dataset}...")
                    
                    victim_arg = victim
                    if victim == 'egnd': victim_arg = 'egnd'

                    cmd = (f"{PYTHON_EXEC} evasion_attack.py "
                           f"--dataset {dataset} "
                           f"--attack {attack} "
                           f"--victim {victim_arg} "
                           f"--ptb_rate {PTB_RATE} "
                           f"--gpu_id {GPU_ID} "
                           f"--save True")
                    
                    run_command(cmd, cwd=".")

    duration = (time.time() - start_time) / 60
    print(f"\nAll tasks finished in {duration:.2f} minutes.")

if __name__ == "__main__":
    main()